import json

from poc import contracts as C
from poc.catalog import get_catalog
from poc.pipeline import STAGES, preprocess
from poc.render import prefix_messages, prefix_sha, stage_block, transcript_tools
from poc.schema import AZURE_UNSUPPORTED, iter_keys, strict_schema
from poc.store import Store


def test_no_azure_unsupported_keywords_anywhere():
    tools = transcript_tools(get_catalog())
    keys = set(iter_keys(tools))
    assert not (keys & AZURE_UNSUPPORTED), keys & AZURE_UNSUPPORTED
    assert "const" not in keys and "x-enum" not in keys


def test_objects_are_strict():
    def walk(node):
        if isinstance(node, dict):
            if node.get("type") == "object":
                assert node["additionalProperties"] is False
                assert set(node["required"]) == set(node["properties"])
            for k, v in node.items():
                if k in ("properties", "$defs"):
                    for sub in v.values():
                        walk(sub)
                else:
                    walk(v)
        elif isinstance(node, list):
            for n in node:
                walk(n)
    walk(transcript_tools(get_catalog()))


def test_catalog_enums_injected_and_field_named_title_kept():
    cat = get_catalog()
    s = strict_schema(C.ConversationMap, cat.enums())
    seg = s["$defs"]["Segment"]
    assert "title" in seg["properties"]                      # a property, not the stripped keyword
    assert seg["properties"]["domains"]["items"]["enum"] == cat.domain_codes
    lit = strict_schema(C.IbanValue, cat.enums())["properties"]["kind"]
    assert lit["enum"] == ["iban"]


def test_value_checks_depend_on_masking():
    from poc.pseudo import PlaceholderMap, mask_types
    from poc.transcript import parse_transcript
    from poc.validate import check_value
    turns = {t.turn_id: t for t in parse_transcript(
        "CLIENT: Yes, I have it here: C H nine three zero zero seven six two zero one one six two three "
        "eight five two nine five seven.")}
    for t in turns.values():
        t.text = t.text_raw                                           # unmasked mode: the LLM sees raw text
    ev = [{"turn": "T001", "quote": "Yes, I have it here"}]
    pmap = PlaceholderMap()
    raw = {"kind": "iban", "value": "CH9300762011623852957"}
    assert any("leak" in i for i in check_value(raw, ev, turns, pmap, mask_types("all")))
    assert check_value(raw, ev, turns, pmap, mask_types("none")) == []
    misheard = {"kind": "iban", "value": "CH9300762011623852958"}
    assert any("checksum" in i for i in check_value(misheard, ev, turns, pmap, mask_types("none")))
    other = {"kind": "iban", "value": "CH5604835012345678009"}       # valid IBAN, but not what was said
    assert any("differs" in i for i in check_value(other, ev, turns, pmap, mask_types("none")))


def test_tool_list_identical_for_every_stage():
    names = [t["function"]["name"] for t in transcript_tools(get_catalog())]
    assert names == [n for n, _, _ in C.TRANSCRIPT_TOOLS]
    assert {STAGES[s][0] for s in STAGES} <= set(names)


def test_prefix_is_byte_identical_and_stage_blocks_differ():
    store = Store()
    ctx = preprocess("call_001_en", store)
    cat = get_catalog()
    tools = transcript_tools(cat)
    p1 = prefix_messages(ctx.fixture_key, ctx.language, ctx.canonical, len(ctx.turns))
    p2 = prefix_messages(ctx.fixture_key, ctx.language, ctx.canonical, len(ctx.turns))
    assert json.dumps(p1) == json.dumps(p2)
    assert prefix_sha(tools, p1) == prefix_sha(transcript_tools(cat), p2)
    b1 = stage_block("detect_cits", tasks=cat.tasks, hint_segments=[])
    assert "emit_cit_candidates" in b1 and ctx.canonical not in b1
    # the transcript sits in the prefix, the variable part comes after it
    assert ctx.canonical in p1[1]["content"]


def test_canonical_render_is_stable_across_preprocess_runs():
    store = Store()
    a = preprocess("call_001_en", store)
    b = preprocess("call_001_en", store)
    assert a.sha == b.sha and a.canonical == b.canonical

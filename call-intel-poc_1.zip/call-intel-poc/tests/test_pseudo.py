import pytest

from poc.pseudo import (ALL_TYPES, EgressBlocked, KnownEntities, PlaceholderMap, egress_guard, iban_valid,
                        mask_types, pseudonymize_text, pseudonymize_turns, scan_raw_pii)
from poc.transcript import parse_transcript

KNOWN = KnownEntities(persons=[{"name": "Hans Müller"}, {"name": "Anna Müller"}, {"name": "Peter Keller"}],
                      emails=["hans.mueller@bluewin.ch"], phones=["+41 44 912 34 56"],
                      addresses=["Seestrasse 12, 8002 Zürich"])


def pz(text, pmap=None):
    return pseudonymize_text(text, pmap or PlaceholderMap(), KNOWN)[0]


def test_spoken_email_is_one_placeholder_not_names():
    assert pz("It's hans dot mueller at bluewin dot ch.") == "It's [EMAIL_1]."


def test_spoken_iban_digit_by_digit():
    out = pz("Here: C H nine three zero zero seven six two zero one one six two three eight five two nine five seven.")
    assert out == "Here: [IBAN_1]."


def test_written_iban_with_spaces_and_checksum():
    assert pz("IBAN CH93 0076 2011 6238 5295 7 please") == "IBAN [IBAN_1] please"
    assert iban_valid("CH9300762011623852957")
    assert not iban_valid("CH9300762011623852958")


def test_invalid_iban_not_masked_as_iban():
    assert "[IBAN" not in pz("C H nine three zero zero seven six two zero one one six two three eight five two nine five eight")


def test_spoken_phone_and_known_phone():
    pmap = PlaceholderMap()
    assert pz("mobile zero seven nine, five five five, one two, three four", pmap) == "mobile [PHONE_1]"
    assert pz("home 044 912 34 56", pmap) == "home [PHONE_2]"
    assert pmap.entries[1]["source"] == "KNOWN"


def test_name_variants_and_same_token():
    pmap = PlaceholderMap()
    assert pz("Good morning Mr Mueller", pmap) == "Good morning Mr [PERSON_1]"
    assert pz("Hans Müller here", pmap) == "[PERSON_1] here"


def test_new_street_address_with_postcode():
    assert pz("We now live at Dorfstrasse 7, 8700 Küsnacht. Since October.") == "We now live at [ADDR_1]. Since October."


def test_discovered_name_masked_everywhere():
    turns = parse_transcript("CLIENT: Send it to my son Thomas please.\nCA: 20,000 to Thomas, correct?")
    pmap, detections = pseudonymize_turns(turns, KNOWN)
    assert "Thomas" not in turns[1].text and "[PERSON_1]" in turns[1].text


def test_rehydrate_roundtrip():
    pmap = PlaceholderMap()
    out = pz("It's hans dot mueller at bluewin dot ch.", pmap)
    assert pmap.rehydrate(out) == "It's hans.mueller@bluewin.ch."


def test_egress_guard_blocks_raw_identifiers():
    with pytest.raises(EgressBlocked):
        egress_guard([{"role": "user", "content": "pay to CH9300762011623852957"}])
    with pytest.raises(EgressBlocked):
        egress_guard([{"role": "user", "content": "mail me at x.y@gmail.com"}])
    egress_guard([{"role": "user", "content": "[T042][CLIENT] It's [EMAIL_1]; amount 20,000 francs."}])


def test_scan_ignores_amounts_and_turn_ids():
    assert scan_raw_pii("[T061][CA] 20,000 francs on the 3rd of November, 0.35 percent") == []


def test_mask_none_sends_raw_text_but_logs_detections():
    turns = parse_transcript("CLIENT: It's hans dot mueller at bluewin dot ch, born on 12.03.1958.")
    pmap, detections = pseudonymize_turns(turns, KNOWN, mask=mask_types("none"))
    assert turns[0].text == turns[0].text_raw and pmap.entries == []
    assert {d["etype"] for d in detections} >= {"EMAIL", "DOB"} and not any(d["masked"] for d in detections)


def test_selective_mask_only_masks_listed_types():
    turns = parse_transcript("CLIENT: It's hans dot mueller at bluewin dot ch, born on 12.03.1958.")
    pseudonymize_turns(turns, KNOWN, mask=mask_types("DOB,AHV,CARD"))
    assert "hans dot mueller" in turns[0].text and "[DOB_1]" in turns[0].text


def test_mask_types_parsing():
    assert mask_types("all") == ALL_TYPES and mask_types("none") == frozenset()
    with pytest.raises(ValueError):
        mask_types("EMAIL,FOO")


def test_egress_guard_only_checks_masked_types():
    msg = [{"role": "user", "content": "pay to CH9300762011623852957"}]
    egress_guard(msg, mask_types("none"))                 # allowed: IBAN is not masked
    egress_guard(msg, mask_types("DOB,AHV,CARD"))
    with pytest.raises(EgressBlocked):
        egress_guard(msg, mask_types("IBAN"))

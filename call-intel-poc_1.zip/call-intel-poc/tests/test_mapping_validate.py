from poc.mapping import fallback_map, needs_retry, repair_map
from poc.transcript import parse_transcript
from poc.validate import numbers_in, quote_score, reconcile


def seg(sid, a, b, phase="advice"):
    return {"segment_id": sid, "phase": phase, "turn_start": a, "turn_end": b, "title": "t", "gist": "g",
            "initiated_by": "CA", "domains": [], "signals": []}


def test_repair_fills_gaps_overlaps_and_tail():
    raw = [seg("S01", "T001", "T010"), seg("S02", "T008", "T020"), seg("S03", "T025", "T030")]
    fixed, issues = repair_map(raw, 40, set())
    assert fixed[0]["turn_start"] == "T001" and fixed[-1]["turn_end"] == "T040"
    for a, b in zip(fixed, fixed[1:]):
        assert int(b["turn_start"][1:]) == int(a["turn_end"][1:]) + 1
    assert any("gap" in i for i in issues) and any("overlap" in i for i in issues)
    assert [s["segment_id"] for s in fixed] == [f"S{i:02d}" for i in range(1, len(fixed) + 1)]


def test_short_segments_merged_and_phases_derived():
    raw = [seg("S01", "T001", "T001", "opening"), seg("S02", "T002", "T010", "advice"),
           seg("S03", "T011", "T020", "advice")]
    fixed, _ = repair_map(raw, 20, set())
    assert len(fixed) == 2 and fixed[0]["phase_id"] == "P1"


def test_unknown_placeholder_blanks_gist():
    s = seg("S01", "T001", "T010")
    s["gist"] = "Client gave [EMAIL_9]"
    fixed, issues = repair_map([s], 10, {"[EMAIL_1]"})
    assert fixed[0]["gist"] == "" and issues


def test_needs_retry_on_low_coverage():
    raw = [seg("S01", "T001", "T010")]
    _, issues = repair_map(raw, 100, set())
    assert needs_retry(raw, issues, 100)


def test_fallback_covers_everything():
    text = "\n".join(f"[00:{i // 60:02d}:{i % 60:02d}] {'CA' if i % 2 else 'CLIENT'}: line {i}" for i in range(80))
    turns = parse_transcript(text)
    segs = fallback_map(turns)
    assert segs[0]["turn_start"] == "T001" and segs[-1]["turn_end"] == turns[-1].turn_id


def test_quote_matching_is_robust_to_punctuation():
    turn = "Yes, I have it here: [IBAN_1]."
    assert quote_score("yes I have it here [IBAN_1]", turn) == 1.0
    assert quote_score("I want to close my account", turn) < 0.85


def test_numbers_normalized():
    assert numbers_in("CHF 20,000 on 3 November") == {"20000", "3"}
    assert numbers_in("[EMAIL_1] at 45%") == {"45"}


def test_reconcile_flags_both_directions():
    summary = {"sections": [{"section_code": "client_instructions", "bullets": [
        {"text": "Transfer CHF 20,000", "turns": ["T048"]}, {"text": "Check fees", "turns": ["T058"]}]}]}
    cands = {"candidates": [
        {"instance_id": "C1", "task_code": "PAYMENT_ORDER", "status": "confirmed", "evidence": [{"turn": "T049"}]},
        {"instance_id": "C2", "task_code": "ADDRESS_CHANGE", "status": "requested", "evidence": [{"turn": "T028"}]}]}
    issues = reconcile(summary, cands)
    assert any("Check fees" in i for i in issues) and any("C2" in i for i in issues)
    assert not any("C1" in i for i in issues)

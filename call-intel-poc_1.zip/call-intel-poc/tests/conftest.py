import os
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))


@pytest.fixture(autouse=True)
def replay_env(tmp_path, monkeypatch):
    """Every test runs offline against a fresh database."""
    monkeypatch.setenv("LLM_MODE", "replay")
    monkeypatch.setenv("LLM_RECORD", "0")
    monkeypatch.setenv("POC_DB_PATH", str(tmp_path / "test.db"))
    from poc import config
    config.get_settings.cache_clear()
    yield
    config.get_settings.cache_clear()

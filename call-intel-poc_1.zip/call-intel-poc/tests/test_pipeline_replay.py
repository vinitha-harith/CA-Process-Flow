"""End to end, offline: the full pipeline on call_001_en with the bundled replay fixtures."""
import asyncio

import pytest

from poc.edits import apply_edit
from poc.llm import LlmClient
from poc.navigator import locate_segments
from poc.pipeline import Pipeline, load_context
from poc.pseudo import iban_valid
from poc.store import Store


def run():
    pipe = Pipeline(store=Store())
    rid = asyncio.run(pipe.run("call_001_en"))
    return pipe.store, rid


@pytest.mark.parametrize("mode", ["all", "none", "DOB,AHV,CARD"])
def test_full_run_completes_with_clean_validation(mode, monkeypatch):
    monkeypatch.setenv("PSEUDONYMIZE_TYPES", mode)
    from poc import config
    config.get_settings.cache_clear()
    store, rid = run()
    assert store.run(rid)["status"] == "complete"
    summ = store.result(rid, "summarize")
    assert summ["validation"]["issues"] == [] and summ["validation"]["bullets"] == {}
    for r in store.results(rid, "extract_cit"):
        assert r["validation"]["status"] == "ok", r["validation"]
    assert len(store.segments(rid)) == 10


def test_unmasked_mode_extracts_real_values(monkeypatch):
    monkeypatch.setenv("PSEUDONYMIZE_TYPES", "none")
    from poc import config
    config.get_settings.cache_clear()
    store, rid = run()
    c4 = {p["param_code"]: p for p in store.result(rid, "extract_cit", "C4")["payload"]["params"]}
    assert c4["beneficiary_iban"]["value"]["value"] == "CH9300762011623852957"
    c2 = {p["param_code"]: p for p in store.result(rid, "extract_cit", "C2")["payload"]["params"]}
    assert c2["client_email"]["value"]["value"] == "hans.mueller@bluewin.ch"
    assert "hans dot mueller" in load_context(store, "call_001_en").canonical


def test_extracted_values_follow_latest_correction_and_rehydrate():
    store, rid = run()
    ctx = load_context(store, "call_001_en")
    c3 = {p["param_code"]: p for p in store.result(rid, "extract_cit", "C3")["payload"]["params"]}
    assert c3["access_level"]["value"]["value"] == "transact"          # view-only was corrected
    c4 = {p["param_code"]: p for p in store.result(rid, "extract_cit", "C4")["payload"]["params"]}
    assert iban_valid(ctx.pmap.value(c4["beneficiary_iban"]["value"]["value"]))
    c2 = {p["param_code"]: p for p in store.result(rid, "extract_cit", "C2")["payload"]["params"]}
    assert c2["client_consent"]["value"]["value"] == "yes"


def test_reconciliation_catches_instruction_outside_catalog():
    store, rid = run()
    recon = store.result(rid, "publish")["payload"]["reconciliation"]
    assert any("custody fees" in r for r in recon)


def test_rerun_reuses_results_without_llm_calls():
    store, rid1 = run()
    pipe = Pipeline(store=store)
    rid2 = asyncio.run(pipe.run("call_001_en"))
    assert store.llm_calls(rid2) == []
    assert all(r["reused"] for r in store.results(rid2) if r["stage"] != "publish")


def test_every_transcript_call_shares_one_prefix():
    store, rid = run()
    shas = {c["prefix_sha"] for c in store.llm_calls(rid)}
    assert len(shas) == 1


def test_navigator_full_text_is_decisive_for_a_clear_hint():
    store, rid = run()
    ctx = load_context(store, "call_001_en")
    nav = locate_segments(store, LlmClient(store=store), rid, ctx.fixture_key, "e-banking access for his wife")
    assert nav.method == "fts" and nav.segment_ids == ["S07"]


def test_edit_creates_new_version_offline():
    store, rid = run()
    res = apply_edit(store, LlmClient(store=store), rid, "SHORTEN", 4, {"target_words": 30})
    versions = store.summary_versions(rid)
    assert len(versions) == 2 and versions[-1]["parent_id"] == versions[0]["id"]
    assert res.offline_mock

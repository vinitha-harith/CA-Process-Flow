"""Pseudonymization (Stage 0): client-identifying data never reaches the LLM.

Layers, in priority order:
1. Known entities from the CRM (this client's names, emails, IBANs, phones, addresses).
2. Pattern recognizers, including spoken forms ("hans dot mueller at bluewin dot ch",
   IBANs and phone numbers read out digit by digit in DE/FR/IT/EN).
3. Light name heuristics (honorifics, "my son Thomas") and, optionally, Presidio NER.

Placeholders are typed and stable per transcript: the same value always gets the
same token ([PERSON_1], [EMAIL_1], [IBAN_1] ...). The mapping stays local.
The egress guard re-scans every prompt before it leaves the machine.
"""
from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass, field
from pathlib import Path

import yaml

from .transcript import Turn

# --- helpers --------------------------------------------------------------------


def fold(s: str) -> str:
    s = s.lower()
    for a, b in (("ä", "ae"), ("ö", "oe"), ("ü", "ue"), ("ß", "ss")):
        s = s.replace(a, b)
    s = unicodedata.normalize("NFKD", s)
    return "".join(c for c in s if not unicodedata.combining(c)).strip()


def iban_valid(iban: str) -> bool:
    s = re.sub(r"\s+", "", iban).upper()
    if not re.fullmatch(r"[A-Z]{2}\d{2}[A-Z0-9]{11,30}", s):
        return False
    lengths = {"CH": 21, "LI": 21, "DE": 22, "AT": 20, "FR": 27, "IT": 27, "GB": 22, "NL": 18, "ES": 24}
    if s[:2] in lengths and len(s) != lengths[s[:2]]:
        return False
    rearranged = s[4:] + s[:4]
    digits = "".join(str(int(c, 36)) for c in rearranged)
    return int(digits) % 97 == 1


def luhn_valid(num: str) -> bool:
    digits = [int(c) for c in num if c.isdigit()]
    if not 13 <= len(digits) <= 19:
        return False
    total = 0
    for i, d in enumerate(reversed(digits)):
        if i % 2 == 1:
            d *= 2
            d = d - 9 if d > 9 else d
        total += d
    return total % 10 == 0


def norm_phone(s: str) -> str:
    d = re.sub(r"\D", "", s)
    if d.startswith("0041"):
        d = "0" + d[4:]
    elif d.startswith("41") and len(d) == 11:
        d = "0" + d[2:]
    return d


EMAIL_RE = re.compile(r"\b[\w.+-]+@[\w-]+(?:\.[\w-]+)+\b")

# --- spans ------------------------------------------------------------------------
# Structured identifiers outrank names (an email address contains name parts);
# within a type, a CRM-known match gets +1 (see Span.rank).
PRIORITY = {"EMAIL": 40, "IBAN": 39, "AHV": 38, "CARD": 37, "PHONE": 36, "DOB": 35, "ADDR": 34,
            "NUMBER": 33, "PERSON": 30, "NER": 10}


@dataclass
class Span:
    start: int
    end: int
    etype: str        # PERSON | EMAIL | IBAN | PHONE | ADDR | DOB | AHV | CARD
    canonical: str    # value used for the stable token and for re-hydration
    source: str       # KNOWN | PATTERN | NER
    priority: int

    @property
    def rank(self) -> int:
        bonus = 1 if self.source == "KNOWN" else 0
        if self.etype == "PERSON" and self.source == "PATTERN":
            bonus -= 15  # heuristic name matches rank below CRM-known names
        return self.priority + bonus


# --- known entities (simulated CRM lookup) -------------------------------------------
@dataclass
class KnownEntities:
    persons: list[dict] = field(default_factory=list)
    emails: list[str] = field(default_factory=list)
    phones: list[str] = field(default_factory=list)
    ibans: list[str] = field(default_factory=list)
    addresses: list[str] = field(default_factory=list)
    dates_of_birth: list[str] = field(default_factory=list)

    @classmethod
    def load(cls, path: Path) -> "KnownEntities":
        if not path.exists():
            return cls()
        data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
        return cls(**{k: data.get(k) or [] for k in cls.__dataclass_fields__})

    def _variants(self, text: str) -> set[str]:
        out = {text}
        for a, b in (("ü", "ue"), ("ö", "oe"), ("ä", "ae"), ("ü", "u"), ("ö", "o"), ("ä", "a")):
            out |= {v.replace(a, b) for v in list(out)}
        return out

    def spans(self, text: str) -> list[Span]:
        found: list[Span] = []

        def add(pattern: str, etype: str, canonical: str) -> None:
            for m in re.finditer(r"(?<![\w])" + re.escape(pattern) + r"(?![\w])", text, re.IGNORECASE):
                found.append(Span(m.start(), m.end(), etype, canonical, "KNOWN", PRIORITY[etype]))

        seen_surnames: set[str] = set()
        for p in self.persons:
            full = p["name"]
            parts = full.split()
            variants = {full, *p.get("variants", [])}
            if len(parts) >= 2:
                given, surname = parts[0], parts[-1]
                if len(given) >= 4:
                    variants.add(given)
                if len(surname) >= 4 and fold(surname) not in seen_surnames:
                    variants.add(surname)  # surname alone -> first listed person with it (the client)
                    seen_surnames.add(fold(surname))
            source = "PATTERN" if p.get("discovered") else "KNOWN"
            for v in variants:
                for vv in self._variants(v):
                    for m in re.finditer(r"(?<![\w])" + re.escape(vv) + r"(?![\w])", text,
                                         0 if p.get("discovered") else re.IGNORECASE):
                        found.append(Span(m.start(), m.end(), "PERSON", fold(full) + "|" + full, source,
                                          PRIORITY["PERSON"]))
        for e in self.emails:
            add(e, "EMAIL", e.lower())
        for a in self.addresses:
            add(a, "ADDR", fold(a) + "|" + a)
            for frag in [x.strip() for x in a.split(",")]:
                if len(frag) >= 6:
                    for vv in self._variants(frag):
                        add(vv, "ADDR", fold(a) + "|" + a)
        for d in self.dates_of_birth:
            add(d, "DOB", d)
        return found


# --- pattern recognizers ----------------------------------------------------------------
SEP_WORDS = r"(?:dot|punkt|point|punto)"
JOIN_WORDS = r"(?:underscore|unterstrich|minus|dash|bindestrich|tiret|trattino|hyphen)"
AT_WORDS = r"(?:at|ät|arobase|chiocciola|klammeraffe)"
TLDS = r"(?:ch|li|com|net|org|de|fr|it|at|eu|io|info|swiss|co|uk)"
SPOKEN_EMAIL = re.compile(
    rf"\b[a-z0-9]+(?:(?:\s+{SEP_WORDS}\s+|\s+{JOIN_WORDS}\s+|[._-])[a-z0-9]+)*"
    rf"(?:\s*@\s*|\s+{AT_WORDS}\s+)"
    rf"[a-z0-9-]+(?:(?:\s+{SEP_WORDS}\s+|\.)[a-z0-9-]+)*(?:\s+{SEP_WORDS}\s+|\.){TLDS}\b",
    re.IGNORECASE,
)
AHV_RE = re.compile(r"\b756[.\s]?\d{4}[.\s]?\d{4}[.\s]?\d{2}\b")
DOB_RE = re.compile(
    r"(?:born on|date of birth(?: is)?|geboren am|geburtsdatum(?: ist)?|n[ée]e? le|nat[oa] il)\s+"
    r"(?P<d>\d{1,2}[./]\s?\d{1,2}[./]\s?\d{2,4}|\d{1,2}\.?\s+[A-Za-zäéû]+\s+\d{4})",
    re.IGNORECASE,
)
STREET_RE = re.compile(
    r"\b(?:[A-ZÄÖÜ][a-zäöüß]+(?:strasse|straße|gasse|weg|platz|allee|rain|ring|halde|quai)\s+\d{1,4}[a-z]?"
    r"|\d{1,4},?\s+(?:rue|avenue|chemin|route|boulevard|place)\s+(?:de\s+la\s+|du\s+|des\s+|de\s+|d')?[A-ZÉ][\w'-]+"
    r"|(?:rue|avenue|chemin|route|boulevard)\s+(?:de\s+la\s+|du\s+|des\s+|de\s+|d')?[A-ZÉ][\w'-]+\s+\d{1,4}"
    r"|via\s+[A-Z][\w'-]+(?:\s+[A-Z][\w'-]+)?\s+\d{1,4})\b"
)
POSTAL_TOWN_RE = re.compile(r"\s*,?\s*(?:in\s+)?\d{4}\s+[A-ZÄÖÜ][a-zäöüéè]+(?:[ -][A-ZÄÖÜ][a-zäöüéè]+)?")
HONORIFIC_RE = re.compile(
    r"\b(?:Herr|Frau|Mr\.?|Mrs\.?|Ms\.?|Monsieur|Madame|Signor|Signora)\s+"
    r"(?P<name>[A-ZÄÖÜ][a-zäöüéè'-]+(?:\s+[A-ZÄÖÜ][a-zäöüéè'-]+)?)"
)
RELATION_RE = re.compile(
    r"\b(?i:my|our|meine?r?|unsere?r?|ma|mon|mia|mio)\s+"
    r"(?i:wife|husband|son|daughter|partner|brother|sister|frau|mann|sohn|tochter|partnerin|partner|"
    r"femme|mari|fils|fille|moglie|marito|figlio|figlia)\s*,?\s+(?P<name>[A-ZÄÖÜ][a-zäöüéè]+)"
)
NAME_STOP = {"He", "She", "They", "And", "The", "Is", "Was", "Er", "Sie", "Und", "Ist", "Il", "Elle",
             "Et", "Lui", "Lei", "Who", "Which", "Will", "Can", "Has", "Hat", "Also", "Auch"}

DIGIT_WORDS = {
    # en
    "zero": "0", "oh": "0", "one": "1", "two": "2", "three": "3", "four": "4", "five": "5", "six": "6",
    "seven": "7", "eight": "8", "nine": "9",
    # de
    "null": "0", "eins": "1", "zwei": "2", "zwo": "2", "drei": "3", "vier": "4", "fünf": "5", "fuenf": "5",
    "sechs": "6", "sieben": "7", "acht": "8", "neun": "9",
    # fr
    "zéro": "0", "un": "1", "deux": "2", "trois": "3", "quatre": "4", "cinq": "5", "sept": "7", "huit": "8",
    "neuf": "9",
    # it
    "uno": "1", "due": "2", "tre": "3", "quattro": "4", "cinque": "5", "sei": "6", "sette": "7", "otto": "8",
    "nove": "9",
    # teens, as people read phone numbers in pairs
    "ten": "10", "eleven": "11", "twelve": "12", "thirteen": "13", "fourteen": "14", "fifteen": "15",
    "sixteen": "16", "seventeen": "17", "eighteen": "18", "nineteen": "19",
    "zehn": "10", "elf": "11", "zwölf": "12", "zwoelf": "12", "dreizehn": "13", "vierzehn": "14",
    "fünfzehn": "15", "sechzehn": "16", "siebzehn": "17", "achtzehn": "18", "neunzehn": "19",
    "dix": "10", "onze": "11", "douze": "12", "treize": "13", "quatorze": "14", "quinze": "15", "seize": "16",
    "dieci": "10", "undici": "11", "dodici": "12", "tredici": "13", "quattordici": "14", "quindici": "15",
    "sedici": "16",
}


def _token_chars(tok: str) -> str | None:
    t = tok.strip(".!?()\"'")
    low = t.lower()
    if not t:
        return None
    if t.isdigit():
        return t
    if low in DIGIT_WORDS:
        return DIGIT_WORDS[low]
    if len(t) == 1 and t.isalpha():
        return t.upper()
    if t.startswith("+") and t[1:].isdigit():
        return t[1:]
    if re.fullmatch(r"[A-Za-z]{2}\d{2}(?:[A-Za-z0-9]{11,30})?", t):
        return t.upper()
    return None


def _scan_runs(text: str) -> list[Span]:
    """IBANs, phone and card numbers, written with spaces or read out digit by digit."""
    spans: list[Span] = []
    toks = []
    for m in re.finditer(r"[^\s,;:]+", text):
        word = m.group()
        trimmed = word.rstrip(".!?)\"'")  # keep sentence punctuation outside the span
        toks.append((m.start(), m.start() + len(trimmed) if trimmed else m.end(), _token_chars(word)))
    i = 0
    while i < len(toks):
        if toks[i][2] is None:
            i += 1
            continue
        j = i
        while j < len(toks) and toks[j][2] is not None:
            j += 1
        run = toks[i:j]
        s, owner, starts, ends = "", [], set(), set()
        for k, (_, _, chars) in enumerate(run):
            starts.add(len(s))
            s += chars
            owner += [k] * len(chars)
            ends.add(len(s))

        def span_for(a: int, b: int) -> tuple[int, int]:
            return run[owner[a]][0], run[owner[b - 1]][1]

        claimed = [False] * len(s)
        # IBAN: longest mod-97-valid candidate aligned on token boundaries
        for a in sorted(starts):
            if a + 15 > len(s) or not (s[a:a + 2].isalpha() and s[a + 2:a + 4].isdigit()):
                continue
            for b in range(min(len(s), a + 34), a + 14, -1):
                if b in ends and iban_valid(s[a:b]) and not any(claimed[a:b]):
                    st, en = span_for(a, b)
                    spans.append(Span(st, en, "IBAN", s[a:b].upper(), "PATTERN", PRIORITY["IBAN"]))
                    claimed[a:b] = [True] * (b - a)
                    break
        # phone (10 digits starting with 0, or +41 + 9) and cards (Luhn)
        for a in sorted(starts):
            if claimed[a]:
                continue
            for length, kind in ((11, "PHONE41"), (10, "PHONE"), (16, "CARD"), (15, "CARD"), (13, "CARD")):
                b = a + length
                if b > len(s) or b not in ends or any(claimed[a:b]) or not s[a:b].isdigit():
                    continue
                cand = s[a:b]
                ok = ((kind == "PHONE" and cand.startswith("0") and cand[1] != "0")
                      or (kind == "PHONE41" and cand.startswith("41"))
                      or (kind == "CARD" and luhn_valid(cand)))
                if ok:
                    st, en = span_for(a, b)
                    etype = "CARD" if kind == "CARD" else "PHONE"
                    canon = cand if etype == "CARD" else norm_phone(cand)
                    spans.append(Span(st, en, etype, canon, "PATTERN", PRIORITY[etype]))
                    claimed[a:b] = [True] * (b - a)
                    break
        # anything else read out digit by digit (>= 5 digit words, e.g. a half-spoken number): mask it
        k = 0
        while k < len(run):
            tok_claimed = lambda q: any(claimed[c] for c in range(len(claimed)) if owner[c] == q)
            if tok_claimed(k):
                k += 1
                continue
            m = k
            while m < len(run) and not tok_claimed(m):
                m += 1
            words = sum(1 for q in range(k, m) if text[run[q][0]:run[q][1]].lower().strip(".!?") in DIGIT_WORDS)
            if words >= 5:
                digits = "".join(run[q][2] for q in range(k, m))
                spans.append(Span(run[k][0], run[m - 1][1], "NUMBER", digits, "PATTERN", PRIORITY["NUMBER"]))
            k = m
        i = j
    return spans


def _email_canonical(raw: str) -> str:
    s = raw.lower()
    s = re.sub(rf"\s+{SEP_WORDS}\s+", ".", s)
    s = re.sub(rf"\s+{JOIN_WORDS}\s+", "-", s)
    s = re.sub(rf"\s+{AT_WORDS}\s+", "@", s)
    return re.sub(r"\s+", "", s)


def pattern_spans(text: str) -> list[Span]:
    spans: list[Span] = []
    for m in EMAIL_RE.finditer(text):
        spans.append(Span(m.start(), m.end(), "EMAIL", m.group().lower(), "PATTERN", PRIORITY["EMAIL"]))
    for m in SPOKEN_EMAIL.finditer(text):
        canon = _email_canonical(m.group())
        if "@" in canon:
            spans.append(Span(m.start(), m.end(), "EMAIL", canon, "PATTERN", PRIORITY["EMAIL"]))
    for m in AHV_RE.finditer(text):
        spans.append(Span(m.start(), m.end(), "AHV", re.sub(r"\D", "", m.group()), "PATTERN", PRIORITY["AHV"]))
    spans += _scan_runs(text)
    for m in DOB_RE.finditer(text):
        spans.append(Span(m.start("d"), m.end("d"), "DOB", m.group("d"), "PATTERN", PRIORITY["DOB"]))
    for m in STREET_RE.finditer(text):
        end = m.end()
        tail = POSTAL_TOWN_RE.match(text, end)
        if tail:
            end = tail.end()
        raw = text[m.start():end]
        spans.append(Span(m.start(), end, "ADDR", fold(raw) + "|" + raw, "PATTERN", PRIORITY["ADDR"]))
    return spans


def name_spans(text: str) -> list[Span]:
    spans: list[Span] = []
    for rx in (HONORIFIC_RE, RELATION_RE):
        for m in rx.finditer(text):
            name = m.group("name")
            if name.split()[0] in NAME_STOP:
                continue
            spans.append(Span(m.start("name"), m.end("name"), "PERSON", fold(name) + "|" + name,
                              "PATTERN", PRIORITY["PERSON"]))
    return spans


_presidio = None


def ner_spans(text: str, lang: str) -> list[Span]:  # pragma: no cover - optional dependency
    global _presidio
    try:
        if _presidio is None:
            from presidio_analyzer import AnalyzerEngine
            _presidio = AnalyzerEngine()
        results = _presidio.analyze(text=text, language=lang if lang in ("en",) else "en",
                                    entities=["PERSON"], score_threshold=0.6)
    except Exception:
        return []
    return [Span(r.start, r.end, "PERSON", fold(text[r.start:r.end]) + "|" + text[r.start:r.end], "NER",
                 PRIORITY["NER"]) for r in results]


def resolve_overlaps(spans: list[Span]) -> list[Span]:
    accepted: list[Span] = []
    for s in sorted(spans, key=lambda s: (-s.rank, -(s.end - s.start), s.start)):
        if all(s.end <= a.start or s.start >= a.end for a in accepted):
            accepted.append(s)
    return sorted(accepted, key=lambda s: s.start)


# --- placeholder map ---------------------------------------------------------------
@dataclass
class PlaceholderMap:
    entries: list[dict] = field(default_factory=list)   # token, etype, value, source, count

    def token_for(self, etype: str, canonical: str, source: str) -> str:
        key = canonical.split("|")[0]
        value = canonical.split("|")[-1]
        for e in self.entries:
            if e["etype"] == etype and e["key"] == key:
                e["count"] += 1
                if source == "KNOWN":
                    e["source"] = "KNOWN"
                return e["token"]
        n = sum(1 for e in self.entries if e["etype"] == etype) + 1
        token = f"[{etype}_{n}]"
        self.entries.append({"token": token, "etype": etype, "key": key, "value": value,
                             "source": source, "count": 1})
        return token

    @property
    def tokens(self) -> set[str]:
        return {e["token"] for e in self.entries}

    def value(self, token: str) -> str | None:
        return next((e["value"] for e in self.entries if e["token"] == token), None)

    def rehydrate(self, text: str) -> str:
        return re.sub(r"\[[A-Z]+_\d+\]", lambda m: self.value(m.group()) or m.group(), text)

    def to_json(self) -> list[dict]:
        return self.entries

    @classmethod
    def from_json(cls, rows: list[dict]) -> "PlaceholderMap":
        return cls(entries=list(rows))


ADJACENT_SAME = re.compile(r"(\[[A-Z]+_\d+\])(?:[\s,;]+\1)+")

# --- what to mask --------------------------------------------------------------------
ALL_TYPES = frozenset({"PERSON", "EMAIL", "IBAN", "PHONE", "ADDR", "DOB", "AHV", "CARD", "NUMBER"})
GUARDED_TYPES = frozenset({"EMAIL", "IBAN", "AHV", "CARD", "PHONE"})   # what the egress guard can detect


def mask_types(spec: str | None = None) -> frozenset[str]:
    """PSEUDONYMIZE_TYPES: "all" (default), "none", or a list such as "DOB,AHV,CARD".

    "none" / a selective list is for deployments whose compliance approval allows client data
    to reach the model (e.g. a private-endpoint deployment) but which still minimise data:
    mask what no extraction needs (date of birth, AHV number, card numbers).
    """
    from .config import get_settings
    spec = (spec if spec is not None else get_settings().pseudonymize_types).strip().upper()
    if spec in ("", "ALL"):
        return ALL_TYPES
    if spec == "NONE":
        return frozenset()
    chosen = {x.strip() for x in spec.split(",") if x.strip()}
    unknown = chosen - ALL_TYPES
    if unknown:
        raise ValueError(f"PSEUDONYMIZE_TYPES: unknown types {sorted(unknown)}; allowed {sorted(ALL_TYPES)}")
    return frozenset(chosen)


def detect_spans(text: str, known: KnownEntities, lang: str = "en", use_presidio: bool = False) -> list[Span]:
    spans = known.spans(text) + pattern_spans(text) + name_spans(text)
    if use_presidio:
        spans += ner_spans(text, lang)
    # Known values found by a pattern recognizer keep the KNOWN source.
    known_emails = {e.lower() for e in known.emails}
    known_ibans = {re.sub(r"\s", "", i).upper() for i in known.ibans}
    known_phones = {norm_phone(p) for p in known.phones}
    for s in spans:
        if (s.etype == "EMAIL" and s.canonical in known_emails) or \
           (s.etype == "IBAN" and s.canonical in known_ibans) or \
           (s.etype == "PHONE" and s.canonical in known_phones):
            s.source = "KNOWN"
    return resolve_overlaps(spans)


def pseudonymize_text(text: str, pmap: PlaceholderMap, known: KnownEntities, lang: str = "en",
                      use_presidio: bool = False, mask: frozenset[str] = ALL_TYPES) -> tuple[str, list[Span]]:
    """Detects every identifier; replaces only the types in `mask`. Returns (text, all detections)."""
    accepted = detect_spans(text, known, lang, use_presidio)
    masked = [s for s in accepted if s.etype in mask]
    tokens = [pmap.token_for(s.etype, s.canonical, s.source) for s in masked]  # first-occurrence order
    out = text
    for s, tok in sorted(zip(masked, tokens), key=lambda x: x[0].start, reverse=True):
        out = out[:s.start] + tok + out[s.end:]
    return ADJACENT_SAME.sub(r"\1", out), accepted


def pseudonymize_turns(turns: list[Turn], known: KnownEntities | None = None, lang: str = "en",
                       use_presidio: bool = False, mask: frozenset[str] = ALL_TYPES
                       ) -> tuple[PlaceholderMap, list[dict]]:
    """Two passes: names discovered anywhere (e.g. "my son Thomas") are handled everywhere.

    Returns the placeholder map (masked types only) and a detection log of every identifier
    found, masked or sent as is - shown in the UI so reviewers see exactly what reached the model.
    """
    known = known or KnownEntities()
    first = PlaceholderMap()
    for t in turns:
        pseudonymize_text(t.text_raw, first, known, lang, use_presidio)
    discovered = [{"name": e["value"], "discovered": True} for e in first.entries
                  if e["etype"] == "PERSON" and e["source"] != "KNOWN"]
    if discovered:
        known = KnownEntities(persons=known.persons + discovered, emails=known.emails, phones=known.phones,
                              ibans=known.ibans, addresses=known.addresses, dates_of_birth=known.dates_of_birth)
    pmap, detections = PlaceholderMap(), []
    for t in turns:
        t.text, spans = pseudonymize_text(t.text_raw, pmap, known, lang, use_presidio, mask)
        for s in spans:
            detections.append({"turn": t.turn_id, "etype": s.etype, "surface": t.text_raw[s.start:s.end],
                               "value": s.canonical.split("|")[-1], "source": s.source,
                               "masked": s.etype in mask})
    return pmap, detections


# --- egress guard -------------------------------------------------------------------
class EgressBlocked(RuntimeError):
    pass


def scan_raw_pii(text: str, types: frozenset[str] = GUARDED_TYPES) -> list[tuple[str, str]]:
    """Direct identifiers of the given types found in a text (values shortened for logs)."""
    hits = []
    for s in pattern_spans(text):
        if s.etype in types:
            v = s.canonical
            hits.append((s.etype, v[:3] + "…" + v[-2:] if len(v) > 6 else "…"))
    return hits


def guarded_types(mask: frozenset[str] | None = None) -> frozenset[str]:
    """The guard only checks types that are supposed to be masked; unmasked types may pass."""
    return GUARDED_TYPES & (mask if mask is not None else mask_types())


def egress_guard(messages: list[dict], mask: frozenset[str] | None = None) -> None:
    types = guarded_types(mask)
    if not types:
        return
    for m in messages:
        content = m.get("content")
        text = content if isinstance(content, str) else str(content)
        hits = scan_raw_pii(text, types)
        if hits:
            raise EgressBlocked(f"Raw identifiers in a {m.get('role')} message: {hits}. Call blocked.")

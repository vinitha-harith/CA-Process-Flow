"""Deterministic prompt rendering.

Prefix layout for every transcript-family call (identical bytes => cache hits):
    tools      : the same 6 output tools, same order (TRANSCRIPT_TOOLS)
    developer  : global_rules.j2 (static)
    user       : <transcript ...> canonical text </transcript>
    -------- shared, cacheable prefix ends here --------
    user       : stage block (stage instructions + stage inputs)
"""
from __future__ import annotations

import hashlib
import json
from functools import lru_cache
from pathlib import Path

from jinja2 import Environment, FileSystemLoader, StrictUndefined

from .catalog import Catalog
from .contracts import TRANSCRIPT_TOOLS, TOOL_MODELS
from .schema import function_tool

PROMPTS = Path(__file__).parent / "prompts"
_env = Environment(loader=FileSystemLoader(PROMPTS), undefined=StrictUndefined,
                   trim_blocks=False, lstrip_blocks=False, keep_trailing_newline=False, autoescape=False)
_env.globals["kind_for"] = lambda data_type: data_type


def _masking() -> tuple[list[str], list[str]]:
    from .pseudo import ALL_TYPES, mask_types
    m = mask_types()
    shown = {"PERSON": "names", "EMAIL": "emails", "IBAN": "IBANs", "PHONE": "phone numbers",
             "ADDR": "addresses", "DOB": "dates of birth", "AHV": "AHV numbers", "CARD": "card numbers"}
    return ([shown[t] for t in sorted(m) if t in shown], [shown[t] for t in sorted(ALL_TYPES - m) if t in shown])


_env.globals["masking"] = _masking

STAGE_TEMPLATES = {
    "build_conversation_map": "stage_map.j2",
    "summarize": "stage_summary.j2",
    "detect_cits": "stage_detect.j2",
    "adjudicate_topics": "stage_topics.j2",
    "extract_cit": "stage_extract.j2",
    "verify_cit": "stage_verify.j2",
}


def render(template: str, **ctx) -> str:
    return _env.get_template(template).render(**ctx).strip()


@lru_cache(maxsize=8)
def _tools_for(catalog_hash: str, enums_json: str) -> tuple[str, ...]:
    enums = json.loads(enums_json)
    return tuple(json.dumps(function_tool(n, m, d, enums)) for n, m, d in TRANSCRIPT_TOOLS)


def transcript_tools(catalog: Catalog) -> list[dict]:
    """The frozen tool list shared by all transcript-family calls."""
    enums_json = json.dumps(catalog.enums(), sort_keys=True)
    return [json.loads(t) for t in _tools_for(catalog.version_hash, enums_json)]


def single_tool(name: str, description: str, catalog: Catalog) -> list[dict]:
    return [function_tool(name, TOOL_MODELS[name], description, catalog.enums())]


def prefix_messages(transcript_id: str, language: str, canonical: str, n_turns: int) -> list[dict]:
    return [
        {"role": "developer", "content": render("global_rules.j2", masked=_masking()[0], unmasked=_masking()[1])},
        {"role": "user", "content": render("transcript.j2", transcript_id=transcript_id, language=language,
                                           canonical=canonical, n_turns=n_turns)},
    ]


def stage_block(stage: str, **ctx) -> str:
    return render(STAGE_TEMPLATES[stage], **ctx)


def prefix_sha(tools: list[dict], prefix: list[dict]) -> str:
    blob = json.dumps({"tools": tools, "messages": prefix}, ensure_ascii=False, sort_keys=True)
    return hashlib.sha256(blob.encode()).hexdigest()[:16]


def prompt_version(stage: str, catalog: Catalog) -> str:
    """Changes whenever the instructions, the tools or the catalogs change."""
    h = hashlib.sha256()
    for name in ("global_rules.j2", "transcript.j2", STAGE_TEMPLATES.get(stage, "edit_request.j2")):
        h.update((PROMPTS / name).read_bytes())
    h.update(json.dumps(transcript_tools(catalog)).encode())
    h.update(catalog.version_hash.encode())
    return h.hexdigest()[:12]

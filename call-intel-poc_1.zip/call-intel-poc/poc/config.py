"""Runtime settings, read from environment variables (and an optional .env file)."""
from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

try:  # python-dotenv is optional
    from dotenv import load_dotenv

    load_dotenv(ROOT / ".env")
except ImportError:  # pragma: no cover
    pass


def _bool(name: str, default: bool) -> bool:
    v = os.getenv(name)
    return default if v is None else v.strip().lower() in {"1", "true", "yes", "on"}


def _float(name: str, default: float) -> float:
    v = os.getenv(name)
    return default if not v else float(v)


@dataclass(frozen=True)
class Settings:
    # --- LLM access -------------------------------------------------------
    llm_mode: str                 # "live" (call Azure OpenAI) or "replay" (offline fixtures)
    record: bool                  # live mode: also write responses to fixtures for offline demos
    api_style: str                # "v1" | "legacy" | "custom"
    endpoint: str                 # https://<resource>.openai.azure.com
    base_url: str                 # only for api_style=custom (e.g. an APIM gateway URL)
    api_key: str
    auth: str                     # "key" | "entra"
    api_version: str              # only for api_style=legacy
    deployment: str               # your gpt-5.1 deployment name
    extra_headers: dict = field(default_factory=dict)
    send_cache_key: bool = True   # send prompt_cache_key (auto-disabled if the endpoint rejects it)
    timeout_s: float = 180.0
    max_concurrency: int = 6
    # --- Behaviour ----------------------------------------------------------
    summary_language: str = "en"
    # --- Prices, USD per 1M tokens (Azure Data Zone list prices; adjust to your contract) ---
    price_input: float = 1.375
    price_cached: float = 0.1375
    price_output: float = 11.0
    # --- Paths --------------------------------------------------------------
    db_path: Path = ROOT / "data" / "poc.db"
    fixtures_dir: Path = ROOT / "data" / "fixtures"
    transcripts_dir: Path = ROOT / "data" / "transcripts"
    catalogs_dir: Path = ROOT / "catalogs"
    use_presidio: bool = False
    # Which identifier types are replaced by placeholders before the LLM call:
    # "all" (default), "none", or a list such as "DOB,AHV,CARD" (see pseudo.mask_types)
    pseudonymize_types: str = "all"

    def cost(self, input_tokens: int, cached_tokens: int, output_tokens: int) -> float:
        uncached = max(input_tokens - cached_tokens, 0)
        return (uncached * self.price_input + cached_tokens * self.price_cached
                + output_tokens * self.price_output) / 1_000_000


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    headers = os.getenv("AZURE_OPENAI_EXTRA_HEADERS", "").strip()
    return Settings(
        llm_mode=os.getenv("LLM_MODE", "replay").strip().lower(),
        record=_bool("LLM_RECORD", False),
        api_style=os.getenv("AZURE_OPENAI_API_STYLE", "v1").strip().lower(),
        endpoint=os.getenv("AZURE_OPENAI_ENDPOINT", "").strip().rstrip("/"),
        base_url=os.getenv("AZURE_OPENAI_BASE_URL", "").strip(),
        api_key=os.getenv("AZURE_OPENAI_API_KEY", "").strip(),
        auth=os.getenv("AZURE_OPENAI_AUTH", "key").strip().lower(),
        api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2025-04-01-preview").strip(),
        deployment=os.getenv("AZURE_OPENAI_DEPLOYMENT", "gpt-5.1").strip(),
        extra_headers=json.loads(headers) if headers else {},
        send_cache_key=_bool("SEND_PROMPT_CACHE_KEY", True),
        timeout_s=_float("LLM_TIMEOUT_S", 180.0),
        max_concurrency=int(os.getenv("LLM_MAX_CONCURRENCY", "6")),
        summary_language=os.getenv("SUMMARY_LANGUAGE", "en").strip().lower(),
        price_input=_float("PRICE_INPUT_PER_M", 1.375),
        price_cached=_float("PRICE_CACHED_PER_M", 0.1375),
        price_output=_float("PRICE_OUTPUT_PER_M", 11.0),
        db_path=Path(os.getenv("POC_DB_PATH", str(ROOT / "data" / "poc.db"))),
        use_presidio=_bool("PSEUDO_USE_PRESIDIO", False),
        pseudonymize_types=os.getenv("PSEUDONYMIZE_TYPES", "all").strip(),
    )

"""Conversation map: validation/repair, deterministic fallback, lexicon and domain routing.

The LLM builds the outline; this module guarantees it is usable:
full, contiguous coverage of every turn, sane segment counts and text lengths.
"""
from __future__ import annotations

import re
from collections import defaultdict

from .catalog import Catalog
from .pseudo import fold
from .transcript import Turn, turn_id, turn_num

PLACEHOLDER = re.compile(r"\[[A-Z]+_\d+\]")


class MapInvalid(RuntimeError):
    pass


def coverage(segments: list[dict], n_turns: int) -> float:
    covered: set[int] = set()
    for s in segments:
        try:
            a, b = turn_num(s["turn_start"]), turn_num(s["turn_end"])
        except (KeyError, ValueError):
            continue
        covered.update(range(max(a, 1), min(b, n_turns) + 1))
    return len(covered) / max(n_turns, 1)


def _merge(a: dict, b: dict) -> dict:
    """Merge b into a (a keeps title/gist/phase)."""
    out = dict(a)
    out["turn_start"] = min(a["turn_start"], b["turn_start"], key=turn_num)
    out["turn_end"] = max(a["turn_end"], b["turn_end"], key=turn_num)
    out["domains"] = sorted(set(a["domains"]) | set(b["domains"]))
    out["signals"] = sorted(set(a["signals"]) | set(b["signals"]))
    return out


def _length(s: dict) -> int:
    return turn_num(s["turn_end"]) - turn_num(s["turn_start"]) + 1


def merge_short(segs: list[dict], min_turns: int = 2) -> list[dict]:
    out = list(segs)
    i = 0
    while i < len(out) and len(out) > 1:
        if _length(out[i]) < min_turns:
            if i > 0:
                out[i - 1] = _merge(out[i - 1], out[i])
            else:
                out[1] = _merge(out[1], out[0])
            out.pop(i)
            continue
        i += 1
    return out


def cap_count(segs: list[dict], max_segments: int = 20) -> list[dict]:
    out = list(segs)
    while len(out) > max_segments:
        pairs = [(i, _length(out[i]) + _length(out[i + 1]), out[i]["phase"] != out[i + 1]["phase"])
                 for i in range(len(out) - 1)]
        i = min(pairs, key=lambda p: (p[2], p[1]))[0]  # prefer same-phase, then smallest
        out[i] = _merge(out[i], out[i + 1])
        out.pop(i + 1)
    return out


def _clip_words(text: str, n: int) -> str:
    words = text.split()
    return text if len(words) <= n else " ".join(words[:n]) + " …"


def check_text(segs: list[dict], placeholders: set[str], issues: list[str]) -> list[dict]:
    out = []
    for s in segs:
        s = dict(s)
        s["title"] = _clip_words(s.get("title", ""), 8)
        s["gist"] = _clip_words(s.get("gist", ""), 40)
        unknown = set(PLACEHOLDER.findall(s["gist"] + " " + s["title"])) - placeholders
        if unknown:
            issues.append(f"{s.get('segment_id')}: unknown placeholders {sorted(unknown)} - gist blanked")
            s["gist"] = ""
        out.append(s)
    return out


def renumber_and_derive_phases(segs: list[dict]) -> list[dict]:
    out, phase_no, prev = [], 0, None
    for i, s in enumerate(segs, start=1):
        s = dict(s)
        if s["phase"] != prev:
            phase_no += 1
            prev = s["phase"]
        s["segment_id"] = f"S{i:02d}"
        s["phase_id"] = f"P{phase_no}"
        out.append(s)
    return out


def repair_map(segments: list[dict], n_turns: int, placeholders: set[str]) -> tuple[list[dict], list[str]]:
    """Guarantee full, contiguous coverage. Returns (segments, issues)."""
    issues: list[str] = []
    valid = []
    for s in segments:
        try:
            turn_num(s["turn_start"]), turn_num(s["turn_end"])
            valid.append(s)
        except (KeyError, ValueError):
            issues.append(f"dropped {s.get('segment_id')}: bad turn ids")
    fixed: list[dict] = []
    cursor = 1
    for s in sorted(valid, key=lambda s: turn_num(s["turn_start"])):
        a = max(turn_num(s["turn_start"]), 1)
        b = min(turn_num(s["turn_end"]), n_turns)
        if b < a or b < cursor:
            issues.append(f"dropped {s.get('segment_id')}: empty or inside an earlier segment")
            continue
        if a > cursor:
            issues.append(f"gap {turn_id(cursor)}-{turn_id(a - 1)}")
            if fixed:
                fixed[-1]["turn_end"] = turn_id(a - 1)
            else:
                a = 1
        elif a < cursor:
            issues.append(f"overlap at {s.get('segment_id')}")
            a = cursor
        fixed.append({**s, "turn_start": turn_id(a), "turn_end": turn_id(b)})
        cursor = b + 1
    if not fixed:
        raise MapInvalid("no usable segments")
    if cursor <= n_turns:
        fixed[-1]["turn_end"] = turn_id(n_turns)
        issues.append("tail gap")
    fixed = merge_short(fixed, min_turns=2)
    fixed = cap_count(fixed, max_segments=20)
    fixed = check_text(fixed, placeholders, issues)
    return renumber_and_derive_phases(fixed), issues


def needs_retry(raw_segments: list[dict], issues: list[str], n_turns: int) -> bool:
    cov = coverage(raw_segments, n_turns)
    structural = [i for i in issues if "placeholders" not in i]
    return (cov < 0.9 or len(structural) > max(3, len(raw_segments) // 10)
            or (n_turns > 100 and len(raw_segments) < 3))


def fallback_map(turns: list[Turn], window: int = 25) -> list[dict]:
    """Deterministic outline used when the LLM map is unusable twice."""
    n = len(turns)
    cuts, target = [], window
    while target < n:
        lo, hi = max(target - 5, 1), min(target + 5, n - 1)
        best, best_gap = target, -1
        for i in range(lo, hi + 1):  # cut before turns[i] (0-based) where the pause is longest
            a, b = turns[i - 1].start_ms, turns[i].start_ms
            gap = (b - a) if a is not None and b is not None else -1
            if gap > best_gap:
                best, best_gap = i, gap
        cuts.append(best)
        target = best + window
    bounds = [0, *cuts, n]
    segs = []
    for k in range(len(bounds) - 1):
        phase = "opening" if k == 0 else "closing" if k == len(bounds) - 2 else "needs_and_situation"
        segs.append({"segment_id": "", "phase": phase, "turn_start": turn_id(bounds[k] + 1),
                     "turn_end": turn_id(bounds[k + 1]), "title": f"Part {k + 1}", "gist": "",
                     "initiated_by": "MIXED", "domains": [], "signals": []})
    return renumber_and_derive_phases(segs)


# --- lexicon booster and domain routing -------------------------------------------
def lexicon_hits(turns: list[Turn], catalog: Catalog) -> dict[str, list[str]]:
    """topic_code -> turn ids where one of its trigger terms occurs (folded, word-boundary)."""
    hits: dict[str, list[str]] = defaultdict(list)
    folded = [(t.turn_id, fold(t.text)) for t in turns]
    for topic in catalog.topics:
        for term in topic.get("trigger_terms", []):
            rx = re.compile(r"(?<!\w)" + re.escape(fold(term)) + r"(?!\w)")
            for tid, text in folded:
                if rx.search(text) and tid not in hits[topic["code"]]:
                    hits[topic["code"]].append(tid)
    return dict(hits)


def domains_to_check(segments: list[dict], lex: dict[str, list[str]], catalog: Catalog,
                     fallback: bool = False, cap: int = 8) -> dict[str, list[str]]:
    """domain -> routed_by sources ('map', 'lexicon', 'fallback'); regulatory first, capped."""
    routed: dict[str, set[str]] = defaultdict(set)
    for s in segments:
        for d in s["domains"]:
            if d in catalog.domain_codes:
                routed[d].add("map")
    for code in lex:
        topic = catalog.topic(code)
        if topic:
            routed[topic["domain"]].add("lexicon")
    if fallback:
        for d in catalog.regulatory_domains:
            routed[d].add("fallback")
    order = sorted(routed, key=lambda d: (d not in catalog.regulatory_domains, catalog.domain_codes.index(d)))
    return {d: sorted(routed[d]) for d in order[:cap]}

"""Transcript parsing, turn segmentation and canonical rendering (Stage 0).

Input format (one utterance per line, diarized):
    [00:01:23] CA: Good morning, Mr Müller.
    [01:30] CLIENT: Good morning.
Lines without a timestamp are accepted. Consecutive lines by the same speaker
are merged into one turn. The canonical rendering is produced ONCE, hashed and
stored; every LLM call sends exactly those bytes (cache prefix identity).
"""
from __future__ import annotations

import hashlib
import re
from dataclasses import asdict, dataclass

LINE = re.compile(r"^\s*(?:\[(?P<ts>\d{1,2}:\d{2}(?::\d{2})?)\]\s*)?(?P<spk>[A-Za-z_]+)\s*:\s*(?P<text>.+?)\s*$")
SPEAKER_ALIASES = {"CA": "CA", "ADVISOR": "CA", "BERATER": "CA", "CONSEILLER": "CA",
                   "CLIENT": "CLIENT", "KUNDE": "CLIENT", "KUNDIN": "CLIENT", "CUSTOMER": "CLIENT"}


@dataclass
class Turn:
    turn_id: str
    idx: int
    speaker: str          # CA | CLIENT | OTHER
    start_ms: int | None
    text_raw: str
    text: str = ""        # pseudonymized text (filled by pseudo.py)


def _ms(ts: str | None) -> int | None:
    if not ts:
        return None
    parts = [int(p) for p in ts.split(":")]
    while len(parts) < 3:
        parts.insert(0, 0)
    h, m, s = parts
    return ((h * 60 + m) * 60 + s) * 1000


def turn_id(idx: int) -> str:
    return f"T{idx:03d}"


def turn_num(tid: str) -> int:
    return int(tid[1:])


def parse_transcript(raw: str) -> list[Turn]:
    turns: list[Turn] = []
    for line in raw.splitlines():
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        m = LINE.match(line)
        if not m:  # continuation line -> append to previous turn
            if turns:
                turns[-1].text_raw += " " + line.strip()
            continue
        spk = SPEAKER_ALIASES.get(m.group("spk").upper(), "OTHER")
        text = m.group("text")
        if turns and turns[-1].speaker == spk:
            turns[-1].text_raw += " " + text
            continue
        idx = len(turns) + 1
        turns.append(Turn(turn_id(idx), idx, spk, _ms(m.group("ts")), text))
    return turns


def render_canonical(turns: list[Turn]) -> str:
    """The exact bytes every LLM call sends. Never re-render elsewhere."""
    return "\n".join(f"[{t.turn_id}][{t.speaker}] {t.text}" for t in turns)


def sha256(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def detect_language(text: str) -> str:
    """Tiny stop-word vote; good enough to label the transcript."""
    words = re.findall(r"[a-zäöüéèàç]+", text.lower())
    votes = {
        "de": {"und", "ich", "die", "der", "nicht", "das", "sie", "ist", "ja", "mit"},
        "fr": {"et", "je", "les", "le", "pas", "vous", "est", "oui", "une", "avec"},
        "it": {"e", "che", "non", "il", "per", "sono", "una", "con", "lei", "grazie"},
        "en": {"and", "the", "i", "you", "is", "not", "yes", "with", "that", "to"},
    }
    scores = {lang: sum(w in vocab for w in words) for lang, vocab in votes.items()}
    return max(scores, key=scores.get)


def turns_to_json(turns: list[Turn]) -> list[dict]:
    return [asdict(t) for t in turns]


def turns_from_json(rows: list[dict]) -> list[Turn]:
    return [Turn(**r) for r in rows]

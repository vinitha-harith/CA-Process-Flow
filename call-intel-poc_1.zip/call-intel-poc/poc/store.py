"""SQLite persistence for the PoC (PostgreSQL in production; same tables, FTS5 instead of tsvector)."""
from __future__ import annotations

import json
import re
import sqlite3
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .config import get_settings

SCHEMA = """
create table if not exists transcripts(
  name text primary key, sha text, language text, call_date text, raw text, canonical text,
  turns_json text, pmap_json text, created_at text, detections_json text, mask text);
create table if not exists runs(
  run_id text primary key, transcript text, sha text, mode text, status text, map_fallback int default 0,
  domains_json text, started_at text, finished_at text, error text);
create table if not exists llm_calls(
  id integer primary key autoincrement, run_id text, stage text, item_id text, prompt_version text,
  deployment text, effort text, cache_key text, prefix_sha text, input_tokens int, cached_tokens int,
  output_tokens int, reasoning_tokens int, latency_ms int, cost_usd real, status text, error text,
  estimated int default 0, created_at text);
create table if not exists results(
  run_id text, stage text, item_id text, cache_key text, status text, payload text, validation text,
  reused int default 0, created_at text, primary key(run_id, stage, item_id));
create index if not exists results_cache on results(cache_key);
create table if not exists segments(
  run_id text, segment_id text, phase_id text, phase text, turn_start text, turn_end text,
  title text, gist text, initiated_by text, domains_json text, signals_json text,
  primary key(run_id, segment_id));
create virtual table if not exists segments_fts using fts5(
  run_id unindexed, segment_id unindexed, title, gist, tokenize='unicode61 remove_diacritics 2');
create table if not exists summary_versions(
  id integer primary key autoincrement, run_id text, parent_id integer, action_code text,
  action_params text, actor text, content text, validation text, created_at text);
create table if not exists reviews(
  id integer primary key autoincrement, run_id text, kind text, item_id text, field text,
  ca_value text, action text, created_at text);
"""


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class Store:
    def __init__(self, path: Path | None = None):
        self.path = Path(path or get_settings().db_path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self.db = sqlite3.connect(self.path, check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self.db.executescript(SCHEMA)
        for col in ("detections_json text", "mask text"):  # databases created by an earlier PoC version
            try:
                self.db.execute(f"alter table transcripts add column {col}")
            except sqlite3.OperationalError:
                pass

    def _exec(self, sql: str, args: tuple = ()) -> sqlite3.Cursor:
        with self._lock:
            cur = self.db.execute(sql, args)
            self.db.commit()
            return cur

    def _all(self, sql: str, args: tuple = ()) -> list[dict]:
        with self._lock:
            return [dict(r) for r in self.db.execute(sql, args).fetchall()]

    def _one(self, sql: str, args: tuple = ()) -> dict | None:
        rows = self._all(sql, args)
        return rows[0] if rows else None

    # --- transcripts --------------------------------------------------------------
    def save_transcript(self, name: str, sha: str, language: str, call_date: str, raw: str,
                        canonical: str, turns: list[dict], pmap: list[dict], detections: list[dict],
                        mask: list[str]) -> None:
        self._exec("insert or replace into transcripts(name, sha, language, call_date, raw, canonical, turns_json, "
                   "pmap_json, created_at, detections_json, mask) values (?,?,?,?,?,?,?,?,?,?,?)",
                   (name, sha, language, call_date, raw, canonical, json.dumps(turns, ensure_ascii=False),
                    json.dumps(pmap, ensure_ascii=False), now(), json.dumps(detections, ensure_ascii=False),
                    ",".join(sorted(mask))))

    def transcript(self, name: str) -> dict | None:
        row = self._one("select * from transcripts where name=?", (name,))
        if row:
            row["turns"] = json.loads(row.pop("turns_json"))
            row["pmap"] = json.loads(row.pop("pmap_json"))
            row["detections"] = json.loads(row.pop("detections_json") or "[]")
        return row

    # --- runs -----------------------------------------------------------------------
    def start_run(self, run_id: str, transcript: str, sha: str, mode: str) -> None:
        self._exec("insert into runs(run_id, transcript, sha, mode, status, started_at) values (?,?,?,?,?,?)",
                   (run_id, transcript, sha, mode, "running", now()))

    def update_run(self, run_id: str, **fields: Any) -> None:
        cols = ", ".join(f"{k}=?" for k in fields)
        self._exec(f"update runs set {cols} where run_id=?", (*fields.values(), run_id))

    def runs(self, transcript: str | None = None) -> list[dict]:
        if transcript:
            return self._all("select * from runs where transcript=? order by started_at desc", (transcript,))
        return self._all("select * from runs order by started_at desc")

    def run(self, run_id: str) -> dict | None:
        return self._one("select * from runs where run_id=?", (run_id,))

    # --- llm call telemetry --------------------------------------------------------
    def log_llm_call(self, **row: Any) -> None:
        row.setdefault("created_at", now())
        cols = ", ".join(row)
        self._exec(f"insert into llm_calls({cols}) values ({', '.join('?' * len(row))})", tuple(row.values()))

    def llm_calls(self, run_id: str | None = None) -> list[dict]:
        if run_id:
            return self._all("select * from llm_calls where run_id=? order by id", (run_id,))
        return self._all("select * from llm_calls order by id")

    # --- stage results (idempotency + application-side cache) ---------------------------
    def save_result(self, run_id: str, stage: str, item_id: str, cache_key: str, status: str,
                    payload: Any, validation: Any = None, reused: bool = False) -> None:
        self._exec("insert or replace into results values (?,?,?,?,?,?,?,?,?)",
                   (run_id, stage, item_id, cache_key, status, json.dumps(payload, ensure_ascii=False),
                    json.dumps(validation, ensure_ascii=False), int(reused), now()))

    def cached_result(self, cache_key: str) -> dict | None:
        row = self._one("select * from results where cache_key=? and status='ok' order by created_at desc limit 1",
                        (cache_key,))
        return self._decode(row) if row else None

    def results(self, run_id: str, stage: str | None = None) -> list[dict]:
        if stage:
            rows = self._all("select * from results where run_id=? and stage=? order by item_id", (run_id, stage))
        else:
            rows = self._all("select * from results where run_id=? order by stage, item_id", (run_id,))
        return [self._decode(r) for r in rows]

    def result(self, run_id: str, stage: str, item_id: str = "-") -> dict | None:
        row = self._one("select * from results where run_id=? and stage=? and item_id=?", (run_id, stage, item_id))
        return self._decode(row) if row else None

    @staticmethod
    def _decode(row: dict) -> dict:
        row["payload"] = json.loads(row["payload"]) if row.get("payload") else None
        row["validation"] = json.loads(row["validation"]) if row.get("validation") else None
        return row

    # --- conversation segments + full-text index ----------------------------------
    def save_segments(self, run_id: str, segments: list[dict]) -> None:
        with self._lock:
            self.db.execute("delete from segments where run_id=?", (run_id,))
            self.db.execute("delete from segments_fts where run_id=?", (run_id,))
            for s in segments:
                self.db.execute("insert into segments values (?,?,?,?,?,?,?,?,?,?,?)",
                                (run_id, s["segment_id"], s.get("phase_id"), s["phase"], s["turn_start"],
                                 s["turn_end"], s["title"], s["gist"], s["initiated_by"],
                                 json.dumps(s["domains"]), json.dumps(s["signals"])))
                self.db.execute("insert into segments_fts(run_id, segment_id, title, gist) values (?,?,?,?)",
                                (run_id, s["segment_id"], s["title"], s["gist"]))
            self.db.commit()

    def segments(self, run_id: str) -> list[dict]:
        rows = self._all("select * from segments where run_id=? order by segment_id", (run_id,))
        for r in rows:
            r["domains"] = json.loads(r.pop("domains_json"))
            r["signals"] = json.loads(r.pop("signals_json"))
        return rows

    def fts_segments(self, run_id: str, query: str, limit: int = 5) -> list[dict]:
        terms = [t for t in re.findall(r"\w+", query.lower()) if len(t) > 2]
        if not terms:
            return []
        match = " OR ".join(f'"{t}"' for t in terms)
        return self._all(
            "select segment_id, -bm25(segments_fts) as rank from segments_fts "
            "where segments_fts match ? and run_id=? order by rank desc limit ?", (match, run_id, limit))

    # --- summary versions and reviews -------------------------------------------------
    def add_summary_version(self, run_id: str, content: dict, parent_id: int | None, action_code: str,
                            action_params: dict, actor: str, validation: Any = None) -> int:
        cur = self._exec("insert into summary_versions(run_id, parent_id, action_code, action_params, actor, "
                         "content, validation, created_at) values (?,?,?,?,?,?,?,?)",
                         (run_id, parent_id, action_code, json.dumps(action_params, ensure_ascii=False), actor,
                          json.dumps(content, ensure_ascii=False), json.dumps(validation, ensure_ascii=False), now()))
        return int(cur.lastrowid)

    def summary_versions(self, run_id: str) -> list[dict]:
        rows = self._all("select * from summary_versions where run_id=? order by id", (run_id,))
        for r in rows:
            r["content"] = json.loads(r["content"])
            r["action_params"] = json.loads(r["action_params"] or "{}")
            r["validation"] = json.loads(r["validation"]) if r.get("validation") else None
        return rows

    def add_review(self, run_id: str, kind: str, item_id: str, field: str, ca_value: str, action: str) -> None:
        self._exec("insert into reviews(run_id, kind, item_id, field, ca_value, action, created_at) "
                   "values (?,?,?,?,?,?,?)", (run_id, kind, item_id, field, ca_value, action, now()))

    def reviews(self, run_id: str) -> list[dict]:
        return self._all("select * from reviews where run_id=? order by id", (run_id,))

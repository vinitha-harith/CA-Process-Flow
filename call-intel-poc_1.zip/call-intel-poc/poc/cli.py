"""Command line: python -m poc <command>

  check                  probe your Azure OpenAI endpoint (auth, strict tools, reasoning_effort,
                         prompt_cache_key, cached_tokens) - run this first
  run NAME [--force]     process data/transcripts/NAME.txt end to end
  report [--run ID]      tokens, cache hit rate and cost per stage
  edit RUN ACTION [--section N] [--param k=v ...]   apply a predefined summary edit
  navigate RUN "hint"    show which call segment a hint resolves to
  cache-experiment NAME  the day-one caching spike: warm-up vs cold fan-out, uniform vs per-stage tools
  generate NAME --lang de --scenario "..."          write a synthetic transcript with GPT-5.1
  list                   transcripts and runs
"""
from __future__ import annotations

import argparse
import asyncio
import dataclasses
import json
import logging
import re
import sys
import uuid
from collections import defaultdict

from .catalog import get_catalog
from .config import get_settings
from .llm import LlmClient, LlmError
from .mapping import fallback_map
from .pipeline import STAGES, Pipeline, load_context, preprocess
from .render import prefix_messages, prefix_sha, single_tool, stage_block, transcript_tools
from .store import Store


def _table(rows: list[dict], cols: list[str]) -> str:
    widths = {c: max(len(c), *(len(str(r.get(c, ""))) for r in rows)) for c in cols} if rows else {c: len(c) for c in cols}
    line = "  ".join(c.ljust(widths[c]) for c in cols)
    sep = "  ".join("-" * widths[c] for c in cols)
    body = ["  ".join(str(r.get(c, "")).ljust(widths[c]) for c in cols) for r in rows]
    return "\n".join([line, sep, *body])


# --- check -------------------------------------------------------------------------------
def cmd_check(_args) -> int:
    s = dataclasses.replace(get_settings(), llm_mode="live", record=False)
    print(f"Endpoint style={s.api_style} auth={s.auth} deployment={s.deployment}")
    print(f"Endpoint: {s.base_url or s.endpoint or '(not set)'}\n")
    llm = LlmClient(s, store=None)
    try:
        text, u = llm.call_text([{"role": "user", "content": "Reply with the single word OK."}], effort="low",
                                max_out=300)
        print(f"[1] plain call ............ OK  reply={text.strip()[:20]!r} tokens in/out={u.input_tokens}/{u.output_tokens}")
    except Exception as e:
        print(f"[1] plain call ............ FAILED: {e}")
        return 1
    store = Store()
    ctx = preprocess("call_001_en", store, s)
    cat = get_catalog()
    tools = single_tool("pick_segments", "Segments the hint refers to.", cat)
    prefix = prefix_messages(ctx.fixture_key, ctx.language, ctx.canonical, len(ctx.turns))
    nonce = uuid.uuid4().hex[:8]
    prefix[0] = {**prefix[0], "content": f"[check {nonce}]\n" + prefix[0]["content"]}  # cold, unique prefix
    msgs = prefix + [{"role": "user", "content": "OUTLINE\nS01 | opening | T001-T005 | Greeting | -\n"
                                                 "S02 | administration | T027-T031 | New address | -\n\nHINT: the move"}]
    results = []
    for i in (1, 2):
        try:
            r = llm.call_tool(run_id="check", stage="check", item_id=str(i), fixture_key=ctx.fixture_key,
                              messages=msgs, tools=tools, tool_name="pick_segments", effort="low", max_out=2000,
                              cache_key=f"check-{nonce}", prompt_version="check", prefix_sha=prefix_sha(tools, prefix))
            results.append(r)
        except LlmError as e:
            print(f"[{i + 1}] strict tool call ...... FAILED: {e}")
            return 1
    r1, r2 = results
    print(f"[2] strict forced tool call  OK  picks={[p['segment_id'] for p in r1.args.get('picks', [])]}")
    print(f"[3] prompt caching ......... cached/input tokens: 1st call {r1.usage.cached_tokens}/{r1.usage.input_tokens}, "
          f"2nd call {r2.usage.cached_tokens}/{r2.usage.input_tokens}")
    if r2.usage.cached_tokens == 0:
        print("    (0 on the 2nd call can be a routing/timing miss; run `python -m poc cache-experiment call_001_en`)")
    for cap in ("reasoning_effort", "prompt_cache_key", "parallel_tool_calls", "developer_role"):
        state = "REJECTED by endpoint (auto-disabled)" if cap in llm.disabled else "accepted"
        print(f"    {cap:<22} {state}")
    print("\nEndpoint ready for LLM_MODE=live.")
    return 0


# --- run / report / list ---------------------------------------------------------------
def cmd_run(args) -> int:
    pipe = Pipeline()
    run_id = asyncio.run(pipe.run(args.name, force=args.force))
    run = pipe.store.run(run_id)
    print(f"run {run_id}: {run['status']}" + (f" ({run['error']})" if run["error"] else ""))
    _print_report(pipe.store, run_id)
    return 0 if run["status"] != "failed" else 1


def _print_report(store: Store, run_id: str | None) -> None:
    calls = [c for c in store.llm_calls(run_id) if c["status"] == "ok"]
    if run_id and not calls:
        reused = sum(r["reused"] for r in store.results(run_id))
        print(f"No LLM calls: all {reused} stage results were reused from the application-side cache "
              "(use --force to recompute).")
        return
    agg: dict[str, dict] = defaultdict(lambda: defaultdict(float))
    for c in calls:
        a = agg[c["stage"]]
        a["calls"] += 1
        for k in ("input_tokens", "cached_tokens", "output_tokens", "reasoning_tokens", "cost_usd", "latency_ms"):
            a[k] += c[k] or 0
    rows = []
    for stage, a in agg.items():
        rows.append({"stage": stage, "calls": int(a["calls"]), "input": int(a["input_tokens"]),
                     "cached": int(a["cached_tokens"]),
                     "cached %": f"{100 * a['cached_tokens'] / max(a['input_tokens'], 1):.0f}",
                     "output": int(a["output_tokens"]), "cost $": f"{a['cost_usd']:.4f}",
                     "avg ms": int(a["latency_ms"] / max(a["calls"], 1))})
    total_in = sum(c["input_tokens"] or 0 for c in calls)
    total_cached = sum(c["cached_tokens"] or 0 for c in calls)
    print(_table(rows, ["stage", "calls", "input", "cached", "cached %", "output", "cost $", "avg ms"]))
    print(f"\nTOTAL {len(calls)} calls, ${sum(c['cost_usd'] for c in calls):.4f}, "
          f"cache hit rate {100 * total_cached / max(total_in, 1):.0f}% of input tokens")
    if any(c["estimated"] for c in calls):
        print("NOTE: replay mode - token figures are ESTIMATES, not measurements. Use LLM_MODE=live for real numbers.")


def cmd_report(args) -> int:
    store = Store()
    run_id = args.run or (store.runs()[0]["run_id"] if store.runs() else None)
    if not run_id:
        print("no runs yet")
        return 1
    print(f"run {run_id}")
    _print_report(store, run_id)
    return 0


def cmd_list(_args) -> int:
    s, store = get_settings(), Store()
    print("Transcripts:", ", ".join(sorted(p.stem for p in s.transcripts_dir.glob("*.txt"))))
    rows = [{k: r[k] for k in ("run_id", "transcript", "mode", "status", "started_at")} for r in store.runs()]
    print(_table(rows, ["run_id", "transcript", "mode", "status", "started_at"]))
    return 0


# --- edit / navigate -------------------------------------------------------------------
def cmd_edit(args) -> int:
    from .edits import apply_edit
    store = Store()
    params = dict(p.split("=", 1) for p in args.param)
    res = apply_edit(store, LlmClient(store=store), args.run, args.action, args.section, params)
    print(f"new summary version {res.version_id}{' (OFFLINE MOCK - no fixture)' if res.offline_mock else ''}")
    if res.navigation:
        print(f"source: {res.navigation.method} -> {res.navigation.segment_ids}")
    print("BEFORE:", json.dumps(res.before, ensure_ascii=False, indent=1)[:1500])
    print("AFTER: ", json.dumps(res.after, ensure_ascii=False, indent=1)[:1500])
    for i in res.issues:
        print("ISSUE:", i)
    return 0


def cmd_navigate(args) -> int:
    from .navigator import locate_segments
    store = Store()
    run = store.run(args.run)
    ctx = load_context(store, run["transcript"])
    nav = locate_segments(store, LlmClient(store=store), args.run, ctx.fixture_key, args.hint)
    print(f"method={nav.method} segments={nav.segment_ids}")
    for h in nav.fts:
        print(f"  fts {h['segment_id']} rank={h['rank']:.2f}")
    for r in nav.reasons:
        print(f"  reason: {r}")
    return 0


# --- cache experiment ----------------------------------------------------------------------
def cmd_cache_experiment(args) -> int:
    """Day-one spike: does cross-stage caching work on YOUR endpoint?"""
    s = dataclasses.replace(get_settings(), llm_mode="live", record=False)
    store = Store()
    llm = LlmClient(s, store)
    cat = get_catalog()
    ctx = preprocess(args.name, store, s)
    segs = fallback_map(ctx.turns)
    g = cat.guidelines
    blocks = {
        "build_conversation_map": stage_block("build_conversation_map", last_turn=ctx.turns[-1].turn_id,
                                              language=s.summary_language, domains=cat.domains, repair_issues=[]),
        "summarize": stage_block("summarize", language=s.summary_language, sections=g["sections"], rules=g["rules"],
                                 max_words=g["max_words_per_bullet"], total_words=g["total_words"], segments=segs),
        "detect_cits": stage_block("detect_cits", tasks=cat.tasks, hint_segments=[]),
    }
    all_tools = transcript_tools(cat)
    exp = uuid.uuid4().hex[:8]

    def call(variant: str, stage: str, uniform: bool):
        tool, _, effort, max_out = STAGES[stage]
        tools = all_tools if uniform else [t for t in all_tools if t["function"]["name"] == tool]
        prefix = prefix_messages(ctx.fixture_key, ctx.language, ctx.canonical, len(ctx.turns))
        prefix[0] = {**prefix[0], "content": f"[experiment {exp}-{variant}]\n" + prefix[0]["content"]}
        return llm.call_tool(run_id=f"exp-{exp}", stage=f"exp:{variant}:{stage}", item_id="-",
                             fixture_key=ctx.fixture_key, messages=prefix + [{"role": "user", "content": blocks[stage]}],
                             tools=tools, tool_name=tool, effort="low", max_out=max_out,
                             cache_key=f"{ctx.fixture_key}-{exp}-{variant}", prompt_version="exp",
                             prefix_sha=prefix_sha(tools, prefix))

    async def variant(name: str, uniform: bool, warmup: bool):
        out = []
        if warmup:
            r = await asyncio.to_thread(call, name, "build_conversation_map", uniform)
            out.append(("build_conversation_map", r))
            rest = await asyncio.gather(*[asyncio.to_thread(call, name, st, uniform) for st in ("summarize", "detect_cits")])
            out += list(zip(("summarize", "detect_cits"), rest))
        else:
            stages = ("build_conversation_map", "summarize", "detect_cits")
            rest = await asyncio.gather(*[asyncio.to_thread(call, name, st, uniform) for st in stages])
            out += list(zip(stages, rest))
        return out

    plan = [("A_uniform_tools_warmup", True, True), ("B_per_stage_tools_warmup", False, True),
            ("C_uniform_tools_cold_fanout", True, False)]
    rows = []
    print(f"Running 3 variants x 3 calls on {args.name} (about $0.10-0.40)...")
    for name, uniform, warmup in plan:
        try:
            res = asyncio.run(variant(name, uniform, warmup))
        except LlmError as e:
            print(f"{name}: FAILED {e}")
            continue
        for stage, r in res:
            rows.append({"variant": name, "stage": stage, "input": r.usage.input_tokens,
                         "cached": r.usage.cached_tokens,
                         "cached %": f"{100 * r.usage.cached_tokens / max(r.usage.input_tokens, 1):.0f}",
                         "ms": r.latency_ms})
    print(_table(rows, ["variant", "stage", "input", "cached", "cached %", "ms"]))
    print("\nRead it as: A should show high cached % on summarize/detect_cits (shared prefix, warm cache).\n"
          "B shows what per-stage schemas cost you; C shows why a cold parallel fan-out misses.")
    return 0


# --- generate ---------------------------------------------------------------------------
GEN_SYSTEM = """You write realistic SYNTHETIC phone-call transcripts between a client advisor (CA) of a fictional
Swiss private bank ("Alpenbank") and a fictional client, for testing software. Never use real people or real banks.
Format, one utterance per line: [hh:mm:ss] CA: text   or   [hh:mm:ss] CLIENT: text
Make it natural: small talk, hesitation, corrections ("actually, ..."), numbers and email addresses SPOKEN out
("anna dot meier at gmail dot com", IBANs read digit by digit). Use valid Swiss IBANs (mod-97) when IBANs occur.
After the transcript, output a YAML block listing the fictional entities a CRM would know about the client
(persons with role, emails, phones, ibans, addresses, dates_of_birth).
Output exactly two fenced blocks: ```transcript ... ``` then ```yaml ... ```."""


def cmd_generate(args) -> int:
    s = dataclasses.replace(get_settings(), llm_mode="live")
    llm = LlmClient(s)
    cat = get_catalog()
    scenario = args.scenario or ("Cover: " + "; ".join(t["name"] for t in cat.tasks[:3]) +
                                 "; one complaint; one change of mind by the client.")
    user = f"Language: {args.lang}. About {args.turns} turns. Scenario: {scenario}"
    text, _ = llm.call_text([{"role": "system", "content": GEN_SYSTEM}, {"role": "user", "content": user}],
                            effort="low", max_out=20000)
    tr = re.search(r"```transcript\s*\n(.*?)```", text, re.S)
    ym = re.search(r"```yaml\s*\n(.*?)```", text, re.S)
    if not tr:
        print("Could not parse the transcript block. Raw output:\n", text[:2000])
        return 1
    header = f"# SYNTHETIC TRANSCRIPT (generated)\n# language: {args.lang}\n# scenario: {scenario[:200]}\n"
    (s.transcripts_dir / f"{args.name}.txt").write_text(header + tr.group(1).strip() + "\n", encoding="utf-8")
    if ym:
        (s.transcripts_dir / f"{args.name}.known.yaml").write_text(ym.group(1).strip() + "\n", encoding="utf-8")
    print(f"wrote data/transcripts/{args.name}.txt" + (" and .known.yaml" if ym else ""))
    return 0


def main(argv: list[str] | None = None) -> int:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")
    p = argparse.ArgumentParser(prog="python -m poc", description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)
    sub.add_parser("check").set_defaults(fn=cmd_check)
    r = sub.add_parser("run")
    r.add_argument("name")
    r.add_argument("--force", action="store_true", help="ignore cached stage results")
    r.set_defaults(fn=cmd_run)
    rp = sub.add_parser("report")
    rp.add_argument("--run")
    rp.set_defaults(fn=cmd_report)
    sub.add_parser("list").set_defaults(fn=cmd_list)
    e = sub.add_parser("edit")
    e.add_argument("run")
    e.add_argument("action")
    e.add_argument("--section", type=int)
    e.add_argument("--param", action="append", default=[])
    e.set_defaults(fn=cmd_edit)
    n = sub.add_parser("navigate")
    n.add_argument("run")
    n.add_argument("hint")
    n.set_defaults(fn=cmd_navigate)
    c = sub.add_parser("cache-experiment")
    c.add_argument("name")
    c.set_defaults(fn=cmd_cache_experiment)
    g = sub.add_parser("generate")
    g.add_argument("name")
    g.add_argument("--lang", default="de")
    g.add_argument("--turns", type=int, default=80)
    g.add_argument("--scenario", default="")
    g.set_defaults(fn=cmd_generate)
    args = p.parse_args(argv)
    return args.fn(args)


if __name__ == "__main__":
    sys.exit(main())

"""Predefined-prompt editing of the AI summary (synchronous; not part of the pipeline).

Each edit: action from the catalog -> source turns (none | segments | routed via the
navigator | full) -> one LLM call returning a section patch (or a whole summary) ->
guardrails -> a new summary version. Nothing is overwritten; every version is kept.
"""
from __future__ import annotations

import copy
import hashlib
import json
import re
from dataclasses import dataclass, field

from pydantic import ValidationError

from . import contracts as C
from . import validate as V
from .catalog import Catalog, get_catalog
from .llm import FixtureMissing, LlmClient, LlmError
from .navigator import Navigation, locate_segments, segment_context
from .pipeline import load_context
from .render import render, single_tool
from .store import Store
from .transcript import turn_num

PLACEHOLDER = re.compile(r"\[[A-Z]+_\d+\]")


@dataclass
class EditResult:
    version_id: int
    before: dict
    after: dict
    issues: list[str] = field(default_factory=list)
    navigation: Navigation | None = None
    offline_mock: bool = False


def action_params(action: dict, given: dict) -> dict:
    out = {p["name"]: p.get("default") for p in action.get("params", [])}
    out.update({k: v for k, v in given.items() if v not in (None, "")})
    return out


def _source_for(action: dict, section: dict | None, params: dict, ctx, store: Store, llm: LlmClient,
                run_id: str) -> tuple[str, Navigation | None]:
    mode = action["source_mode"]
    segments = store.segments(run_id)
    if mode == "none":
        return "", None
    if mode == "full":
        return ctx.canonical, None
    if mode == "routed" and params.get("hint"):
        nav = locate_segments(store, llm, run_id, ctx.fixture_key, params["hint"])
        return segment_context(ctx.turns, segments, nav.segment_ids), nav
    # "segments" (or routed without a hint): the section's own segment, else segments its citations fall in
    ids = []
    if section and section.get("segment_id"):
        ids = [section["segment_id"]]
    elif section:
        cited = {turn_num(t) for b in section["bullets"] for t in b["turns"]}
        ids = [s["segment_id"] for s in segments
               if any(turn_num(s["turn_start"]) <= c <= turn_num(s["turn_end"]) for c in cited)]
    return segment_context(ctx.turns, segments, ids), Navigation(ids, "section")


def _offline_mock(action: dict, current: dict, params: dict, scope: str) -> dict:
    """Deterministic stand-in when replaying without a recorded fixture. Clearly labelled in the UI."""
    out = copy.deepcopy(current)
    bullets = out["sections"] if scope == "whole" else [out]
    for sec in bullets:
        for b in sec["bullets"]:
            if action["code"] in ("SHORTEN", "BULLETS_TIGHTEN"):
                words = b["text"].split()
                b["text"] = " ".join(words[:12]) + (" …" if len(words) > 12 else "")
            elif action["code"] == "TRANSLATE":
                b["text"] = f"[{params.get('language')}] {b['text']}"
    if scope == "whole":
        out["language"] = params.get("language", out.get("language"))
    return out


def _style_guard(before: dict, after: dict) -> list[str]:
    """Style-only edits may not introduce numbers or placeholders that were not there."""
    b_txt, a_txt = json.dumps(before, ensure_ascii=False), json.dumps(after, ensure_ascii=False)
    issues = []
    new_numbers = V.numbers_in(a_txt) - V.numbers_in(b_txt)
    if new_numbers:
        issues.append(f"style edit introduced numbers {sorted(new_numbers)}")
    new_ph = set(PLACEHOLDER.findall(a_txt)) - set(PLACEHOLDER.findall(b_txt))
    if new_ph:
        issues.append(f"style edit introduced placeholders {sorted(new_ph)}")
    return issues


def apply_edit(store: Store, llm: LlmClient, run_id: str, action_code: str, section_index: int | None,
               params: dict | None = None, base_version_id: int | None = None,
               catalog: Catalog | None = None) -> EditResult:
    cat = catalog or get_catalog()
    action = cat.edit_action(action_code)
    if action is None:
        raise ValueError(f"unknown action {action_code}")
    run = store.run(run_id)
    ctx = load_context(store, run["transcript"])
    versions = store.summary_versions(run_id)
    if not versions:
        raise ValueError("this run has no summary")
    base = next((v for v in versions if v["id"] == base_version_id), versions[-1])
    summary = base["content"]
    params = action_params(action, params or {})
    scope = action["scope"]
    if scope == "section":
        if section_index is None:
            raise ValueError(f"{action_code} needs a section")
        current = summary["sections"][section_index]
        rule = cat.section(current["section_code"]) or {}
        section_rule = f"{rule.get('content', '')} {rule.get('rules', '')} Max {rule.get('max_bullets')} bullets."
        tool, model = "emit_section_patch", C.SectionPatch
    else:
        current, section_rule, tool, model = summary, "", "emit_summary_edit", C.Summary

    source, nav = _source_for(action, current if scope == "section" else None, params, ctx, store, llm, run_id)
    messages = [
        {"role": "developer", "content": render("edit_rules.j2")},
        {"role": "user", "content": render("edit_request.j2", scope=scope,
                                           current_json=json.dumps(current, ensure_ascii=False, indent=1),
                                           section_rule=section_rule, source=source,
                                           action_text=action["template"].format(**params), tool_name=tool)},
    ]
    item = f"{action_code}_{section_index if section_index is not None else 'all'}_" + \
           hashlib.sha256(json.dumps(params, sort_keys=True).encode()).hexdigest()[:6]
    mock = False
    try:
        res = llm.call_tool(run_id=run_id, stage="edit", item_id=item, fixture_key=ctx.fixture_key,
                            messages=messages, tools=single_tool(tool, "The edited summary content.", cat),
                            tool_name=tool, effort=action.get("effort"), max_out=12000, cache_key=None,
                            prompt_version="edit-1", prefix_sha="-")
        after = model.model_validate(res.args).model_dump()
    except FixtureMissing:
        after, mock = _offline_mock(action, current, params, scope), True
    except ValidationError as e:
        raise LlmError(f"edit output failed validation: {e}") from e

    issues = _style_guard(current, after) if action["source_mode"] == "none" else []
    new = copy.deepcopy(summary)
    if scope == "section":
        after["section_code"] = current["section_code"]  # an edit never moves a section
        new["sections"][section_index] = after
    else:
        new = after
    validation = V.validate_summary(new, ctx.turns_by_id, store.segments(run_id), ctx.pmap, cat)
    if issues:
        validation["issues"] = issues + validation["issues"]
    vid = store.add_summary_version(run_id, new, base["id"], action_code, params, "CA", validation)
    return EditResult(vid, current, after, issues + validation["issues"], nav, mock)

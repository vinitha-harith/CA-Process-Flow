"""Navigator: finds the part of a call a hint refers to (in-house tree navigation, no vectors).

Step 1: full-text search over segment titles + gists (SQLite FTS5 here, Postgres tsvector in production).
Step 2: only if step 1 is not decisive, one small LLM call over the outline (~1k tokens).
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field

from .catalog import get_catalog
from .llm import LlmClient, LlmError
from .render import render, single_tool
from .store import Store
from .transcript import Turn, turn_num

log = logging.getLogger("poc.navigator")
FTS_MIN = 0.5          # minimum bm25-derived rank to trust a single hit
FTS_DOMINANCE = 1.5    # top hit must beat the runner-up by this factor


@dataclass
class Navigation:
    segment_ids: list[str]
    method: str                                   # fts | llm | fts_fallback | none
    fts: list[dict] = field(default_factory=list)
    reasons: list[str] = field(default_factory=list)


def render_outline(segments: list[dict]) -> str:
    return "\n".join(f"{s['segment_id']} | {s['phase']} | {s['turn_start']}-{s['turn_end']} | "
                     f"{s['title']} | {s['gist']}" for s in segments)


def locate_segments(store: Store, llm: LlmClient, run_id: str, fixture_key: str, hint: str,
                    max_picks: int = 3) -> Navigation:
    hits = store.fts_segments(run_id, hint)
    if hits and hits[0]["rank"] >= FTS_MIN and (len(hits) == 1 or hits[0]["rank"] >= FTS_DOMINANCE * hits[1]["rank"]):
        return Navigation([hits[0]["segment_id"]], "fts", hits)
    segments = store.segments(run_id)
    valid = {s["segment_id"] for s in segments}
    messages = [{"role": "developer", "content": render("navigator.j2")},
                {"role": "user", "content": f"OUTLINE\n{render_outline(segments)}\n\nHINT: {hint}"}]
    try:
        res = llm.call_tool(run_id=run_id, stage="navigate", item_id=_slug(hint), fixture_key=fixture_key,
                            messages=messages, tools=single_tool("pick_segments", "Segments the hint refers to.",
                                                                 get_catalog()),
                            tool_name="pick_segments", effort="none", max_out=2000, cache_key=None,
                            prompt_version="nav-1", prefix_sha="-")
        picks = [p for p in res.args.get("picks", []) if p["segment_id"] in valid][:max_picks]
        return Navigation([p["segment_id"] for p in picks], "llm", hits, [p["reason"] for p in picks])
    except LlmError as e:  # offline replay without a fixture -> best FTS guess, clearly labelled
        log.info("navigator LLM step unavailable (%s); using FTS ranking", e)
        ids = [h["segment_id"] for h in hits[:max_picks]]
        return Navigation(ids, "fts_fallback" if ids else "none", hits)


def segment_context(turns: list[Turn], segments: list[dict], segment_ids: list[str], pad: int = 2,
                    max_chars: int = 16000) -> str:
    """Turns of the chosen segments (+/- pad turns), merged, first-ranked segment kept whole."""
    by_id = {s["segment_id"]: s for s in segments}
    wanted: list[int] = []
    for sid in segment_ids:
        s = by_id.get(sid)
        if not s:
            continue
        a, b = turn_num(s["turn_start"]) - pad, turn_num(s["turn_end"]) + pad
        wanted += [i for i in range(max(a, 1), min(b, len(turns)) + 1) if i not in wanted]
    lines, size = [], 0
    for i in wanted:
        t = turns[i - 1]
        line = f"[{t.turn_id}][{t.speaker}] {t.text}"
        if size + len(line) > max_chars and lines:
            break
        lines.append(line)
        size += len(line)
    return "\n".join(sorted(lines, key=lambda l: turn_num(l[1:l.index("]")])))


def _slug(text: str) -> str:
    import hashlib
    return hashlib.sha256(text.strip().lower().encode()).hexdigest()[:10]

"""Pydantic model -> Azure OpenAI strict function-tool schema.

Azure structured outputs support a JSON-Schema subset: no `pattern`, `format`,
length or numeric bounds; every property required; additionalProperties false.
We generate the schema from Pydantic, strip what Azure rejects, inject catalog
enums, and keep Pydantic as the validator for the stripped regexes.
"""
from __future__ import annotations

import copy
from typing import Any

from pydantic import BaseModel

AZURE_UNSUPPORTED = {
    "pattern", "format", "minLength", "maxLength", "minimum", "maximum", "exclusiveMinimum",
    "exclusiveMaximum", "multipleOf", "minItems", "maxItems", "uniqueItems", "patternProperties",
    "unevaluatedProperties", "propertyNames", "minProperties", "maxProperties", "contains",
    "minContains", "maxContains", "unevaluatedItems", "default", "title", "examples", "discriminator",
}


def _schema_node(node: Any, enums: dict[str, list[str]]) -> Any:
    """Process a node that IS a schema (not a mapping of property names)."""
    if isinstance(node, list):
        return [_schema_node(n, enums) for n in node]
    if not isinstance(node, dict):
        return node
    if "$ref" in node:  # strict mode: no sibling keywords next to $ref
        return {"$ref": node["$ref"]}
    out: dict[str, Any] = {}
    for key, value in node.items():
        if key in AZURE_UNSUPPORTED:
            continue
        if key in ("properties", "$defs"):
            out[key] = {name: _schema_node(sub, enums) for name, sub in value.items()}
        elif key in ("items", "anyOf", "allOf", "oneOf", "additionalProperties"):
            out[key] = _schema_node(value, enums)
        else:
            out[key] = value
    if "x-enum" in out:
        name = out.pop("x-enum")
        out["enum"] = list(enums[name])
    if "const" in out:  # Literal["iban"] -> single-value enum, the form Azure documents
        const = out.pop("const")
        out.setdefault("enum", [const])
        out.setdefault("type", "string" if isinstance(const, str) else "number")
    if "oneOf" in out:  # strict mode supports anyOf, not oneOf
        out["anyOf"] = out.pop("oneOf")
    if "anyOf" in out and len(out["anyOf"]) == 1:
        only = out.pop("anyOf")[0]
        out = {**only, **{k: v for k, v in out.items() if k == "description"}}
    if out.get("type") == "object" or "properties" in out:
        props = out.setdefault("properties", {})
        out["type"] = "object"
        out["required"] = list(props.keys())
        out["additionalProperties"] = False
    return out


def strict_schema(model: type[BaseModel], enums: dict[str, list[str]]) -> dict:
    raw = copy.deepcopy(model.model_json_schema(mode="validation"))
    return _schema_node(raw, enums)


def function_tool(name: str, model: type[BaseModel], description: str,
                  enums: dict[str, list[str]]) -> dict:
    return {
        "type": "function",
        "function": {
            "name": name,
            "description": description,
            "strict": True,
            "parameters": strict_schema(model, enums),
        },
    }


def iter_keys(node: Any):
    """Yield every schema keyword (not property names) - used by tests."""
    if isinstance(node, list):
        for n in node:
            yield from iter_keys(n)
    elif isinstance(node, dict):
        for k, v in node.items():
            yield k
            if k in ("properties", "$defs"):
                for sub in v.values():
                    yield from iter_keys(sub)
            else:
                yield from iter_keys(v)

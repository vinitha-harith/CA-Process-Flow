"""The orchestrator (asyncio). Same stages and fan-out shape as the Durable Functions design:

    0 preprocess (no LLM, masks PSEUDONYMIZE_TYPES)  ->  1 conversation map (sequential warm-up)
    ->  2 fan-out: summary | CIT detection | topic adjudication x k domains
    ->  3 fan-out: CIT extraction x n  ->  4 fan-out: verification x m (high-risk)
    ->  5 validate & publish (no LLM)

Porting to Durable: each `_stage_*` coroutine becomes an activity; `asyncio.gather` becomes
`context.task_all`. Activities pass IDs and load/persist their own data, exactly as here.
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import uuid
from dataclasses import dataclass
from datetime import date
from typing import Any

from pydantic import BaseModel, ValidationError

from . import contracts as C
from . import validate as V
from .catalog import Catalog, get_catalog
from .config import Settings, get_settings
from .llm import LlmClient, LlmError
from .mapping import (MapInvalid, domains_to_check, fallback_map, lexicon_hits, needs_retry,
                      repair_map)
from .pseudo import KnownEntities, PlaceholderMap, mask_types, pseudonymize_turns
from .render import prefix_messages, prefix_sha, prompt_version, stage_block, transcript_tools
from .store import Store
from .transcript import (Turn, detect_language, parse_transcript, render_canonical, sha256,
                         turns_from_json, turns_to_json)

log = logging.getLogger("poc.pipeline")

# stage -> (tool name, output model, reasoning effort, max completion tokens incl. reasoning)
STAGES: dict[str, tuple[str, type[BaseModel], str, int]] = {
    "build_conversation_map": ("emit_conversation_map", C.ConversationMap, "low", 16000),
    "summarize": ("emit_summary", C.Summary, "low", 16000),
    "detect_cits": ("emit_cit_candidates", C.CitCandidates, "medium", 16000),
    "adjudicate_topics": ("emit_topic_flags", C.TopicFlags, "low", 10000),
    "extract_cit": ("emit_cit_extraction", C.CitExtraction, "low", 10000),
    "verify_cit": ("emit_verification", C.Verification, "medium", 12000),
}


@dataclass
class CallContext:
    name: str
    sha: str
    language: str
    call_date: str
    canonical: str
    turns: list[Turn]
    pmap: PlaceholderMap

    @property
    def fixture_key(self) -> str:
        return self.sha[:16]

    @property
    def turns_by_id(self) -> dict[str, Turn]:
        return {t.turn_id: t for t in self.turns}

    def prefix(self) -> list[dict]:
        return prefix_messages(self.fixture_key, self.language, self.canonical, len(self.turns))


def _read_header(raw: str) -> dict[str, str]:
    meta = {}
    for line in raw.splitlines():
        if line.startswith("#") and ":" in line:
            k, v = line[1:].split(":", 1)
            meta[k.strip().lower()] = v.strip()
    return meta


def preprocess(name: str, store: Store, settings: Settings | None = None) -> CallContext:
    """Stage 0: parse, pseudonymize, render once, hash, store."""
    s = settings or get_settings()
    path = s.transcripts_dir / f"{name}.txt"
    raw = path.read_text(encoding="utf-8")
    meta = _read_header(raw)
    turns = parse_transcript(raw)
    if not turns:
        raise ValueError(f"{path} contains no turns")
    language = meta.get("language") or detect_language(" ".join(t.text_raw for t in turns))
    known = KnownEntities.load(s.transcripts_dir / f"{name}.known.yaml")
    mask = mask_types(s.pseudonymize_types)
    pmap, detections = pseudonymize_turns(turns, known, language, s.use_presidio, mask)
    canonical = render_canonical(turns)
    sha = sha256(canonical)
    call_date = meta.get("date") or date.today().isoformat()
    store.save_transcript(name, sha, language, call_date, raw, canonical, turns_to_json(turns), pmap.to_json(),
                          detections, sorted(mask))
    return CallContext(name, sha, language, call_date, canonical, turns, pmap)


def load_context(store: Store, name: str) -> CallContext:
    row = store.transcript(name)
    if row is None:
        raise KeyError(f"transcript {name} not preprocessed yet")
    return CallContext(name, row["sha"], row["language"], row["call_date"], row["canonical"],
                       turns_from_json(row["turns"]), PlaceholderMap.from_json(row["pmap"]))


class Pipeline:
    def __init__(self, store: Store | None = None, llm: LlmClient | None = None,
                 catalog: Catalog | None = None, settings: Settings | None = None):
        self.s = settings or get_settings()
        self.store = store or Store()
        self.llm = llm or LlmClient(self.s, self.store)
        self.cat = catalog or get_catalog()
        self.force = False

    # --- helpers -------------------------------------------------------------------
    def _cache_key(self, ctx: CallContext, stage: str, item: str, extra: Any = "") -> str:
        blob = json.dumps([ctx.sha, stage, item, prompt_version(stage, self.cat), self.s.deployment,
                           self.s.summary_language, extra], sort_keys=True, ensure_ascii=False)
        return hashlib.sha256(blob.encode()).hexdigest()[:24]

    def _reuse(self, run_id: str, stage: str, item: str, key: str) -> dict | None:
        if self.force:
            return None
        hit = self.store.cached_result(key)
        if hit:
            self.store.save_result(run_id, stage, item, key, "ok", hit["payload"], hit["validation"], reused=True)
            return hit
        return None

    async def _call(self, run_id: str, ctx: CallContext, stage: str, item_id: str, block: str,
                    warm: bool = True) -> dict:
        tool, model, effort, max_out = STAGES[stage]
        tools = transcript_tools(self.cat)
        prefix = ctx.prefix()
        messages = prefix + [{"role": "user", "content": block}]
        p_sha = prefix_sha(tools, prefix)
        p_chars = len(json.dumps(tools)) + sum(len(m["content"]) for m in prefix)
        attempt_item = item_id
        for attempt in range(2):
            res = await asyncio.to_thread(
                self.llm.call_tool, run_id=run_id, stage=stage, item_id=attempt_item,
                fixture_key=ctx.fixture_key, messages=messages, tools=tools, tool_name=tool, effort=effort,
                max_out=max_out, cache_key=ctx.fixture_key, prompt_version=prompt_version(stage, self.cat),
                prefix_sha=p_sha, prefix_chars=p_chars, warm=warm)
            try:
                return model.model_validate(res.args).model_dump()
            except ValidationError as e:
                if attempt == 1 or self.s.llm_mode == "replay":
                    raise LlmError(f"{stage}/{item_id}: output failed validation: {e}") from e
                # one repair retry: same cached prefix, error appended after the stage block
                messages = messages + [{"role": "user", "content":
                                        f"Your previous output failed validation:\n{e}\nFix it and call {tool} again."}]
                attempt_item = f"{item_id}#repair"
        raise LlmError("unreachable")

    # --- the run ---------------------------------------------------------------------
    async def run(self, name: str, force: bool = False) -> str:
        self.force = force
        run_id = uuid.uuid4().hex[:12]
        ctx = preprocess(name, self.store, self.s)
        self.store.start_run(run_id, name, ctx.sha, self.s.llm_mode)
        failed: list[str] = []

        async def safe(stage: str, item: str, coro):
            try:
                return await coro
            except Exception as e:  # fail soft per item: the run is published as partial
                log.exception("%s/%s failed", stage, item)
                self.store.save_result(run_id, stage, item, "", "failed", None, {"error": str(e)[:1000]})
                failed.append(f"{stage}/{item}")
                return None

        try:
            segments, fallback = await self._stage_map(run_id, ctx)
            lex = lexicon_hits(ctx.turns, self.cat)
            routing = domains_to_check(segments, lex, self.cat, fallback=fallback)
            self.store.update_run(run_id, map_fallback=int(fallback),
                                  domains_json=json.dumps({"routing": routing, "lexicon": lex}))

            stage2 = [safe("summarize", "-", self._stage_summary(run_id, ctx, segments)),
                      safe("detect_cits", "-", self._stage_detect(run_id, ctx, segments))]
            stage2 += [safe("adjudicate_topics", d, self._stage_topics(run_id, ctx, segments, d, lex))
                       for d in routing]
            summary, cands, *_ = await asyncio.gather(*stage2)

            active = [c for c in (cands or {}).get("candidates", []) if c["status"] in ("requested", "confirmed")
                      and self.cat.task(c["task_code"])]
            extractions = await asyncio.gather(*[
                safe("extract_cit", c["instance_id"], self._stage_extract(run_id, ctx, c)) for c in active])

            risky = [(c, e) for c, e in zip(active, extractions)
                     if e and self.cat.task(c["task_code"]).get("risk_tier") == "high"]
            await asyncio.gather(*[safe("verify_cit", c["instance_id"], self._stage_verify(run_id, ctx, c, e))
                                   for c, e in risky])

            recon = V.reconcile(summary, cands)
            self.store.save_result(run_id, "publish", "-", "", "ok", {"reconciliation": recon, "failed": failed})
            if summary:
                val = V.validate_summary(summary, ctx.turns_by_id, segments, ctx.pmap, self.cat)
                self.store.add_summary_version(run_id, summary, None, "AI_DRAFT", {}, "pipeline", val)
            self.store.update_run(run_id, status="partial" if failed else "complete",
                                  finished_at=_now(), error="; ".join(failed) or None)
        except Exception as e:
            log.exception("run %s failed", run_id)
            self.store.update_run(run_id, status="failed", finished_at=_now(), error=str(e)[:1000])
            raise
        return run_id

    # --- stages ------------------------------------------------------------------------
    async def _stage_map(self, run_id: str, ctx: CallContext) -> tuple[list[dict], bool]:
        stage = "build_conversation_map"
        key = self._cache_key(ctx, stage, "-")
        hit = self._reuse(run_id, stage, "-", key)
        if hit:
            segments = hit["payload"]["segments"]
            self.store.save_segments(run_id, segments)
            return segments, hit["payload"].get("fallback", False)
        n = len(ctx.turns)
        args = dict(last_turn=ctx.turns[-1].turn_id, language=self.s.summary_language, domains=self.cat.domains)
        fallback, issues, purpose = False, [], ""
        try:
            out = await self._call(run_id, ctx, stage, "-", stage_block(stage, repair_issues=[], **args), warm=False)
            segments, issues = repair_map(out["segments"], n, ctx.pmap.tokens)
            if needs_retry(out["segments"], issues, n):
                out = await self._call(run_id, ctx, stage, "retry", stage_block(stage, repair_issues=issues, **args))
                segments, issues = repair_map(out["segments"], n, ctx.pmap.tokens)
                if needs_retry(out["segments"], issues, n):
                    raise MapInvalid("; ".join(issues))
            purpose = out["call_purpose"]
        except (MapInvalid, LlmError) as e:
            log.warning("map unusable (%s) - deterministic fallback", e)
            segments, fallback, issues = fallback_map(ctx.turns), True, [f"fallback: {e}"]
        payload = {"call_purpose": purpose, "segments": segments, "fallback": fallback}
        self.store.save_segments(run_id, segments)
        self.store.save_result(run_id, stage, "-", key if not fallback else "", "ok" if not fallback else "fallback",
                               payload, {"issues": issues})
        return segments, fallback

    async def _stage_summary(self, run_id: str, ctx: CallContext, segments: list[dict]) -> dict:
        stage = "summarize"
        key = self._cache_key(ctx, stage, "-", [s["segment_id"] + s["turn_start"] for s in segments])
        if hit := self._reuse(run_id, stage, "-", key):
            return hit["payload"]
        g = self.cat.guidelines
        block = stage_block(stage, language=self.s.summary_language, sections=g["sections"], rules=g["rules"],
                            max_words=g["max_words_per_bullet"], total_words=g["total_words"], segments=segments)
        out = await self._call(run_id, ctx, stage, "-", block)
        val = V.validate_summary(out, ctx.turns_by_id, segments, ctx.pmap, self.cat)
        self.store.save_result(run_id, stage, "-", key, "ok", out, val)
        return out

    async def _stage_detect(self, run_id: str, ctx: CallContext, segments: list[dict]) -> dict:
        stage = "detect_cits"
        key = self._cache_key(ctx, stage, "-")
        if hit := self._reuse(run_id, stage, "-", key):
            return hit["payload"]
        hints = [s for s in segments if {"instruction", "consent_discussion", "cancellation"} & set(s["signals"])]
        out = await self._call(run_id, ctx, stage, "-", stage_block(stage, tasks=self.cat.tasks, hint_segments=hints))
        self.store.save_result(run_id, stage, "-", key, "ok", out,
                               V.validate_candidates(out, ctx.turns_by_id, self.cat))
        return out

    async def _stage_topics(self, run_id: str, ctx: CallContext, segments: list[dict], domain: str,
                            lex: dict[str, list[str]]) -> dict:
        stage = "adjudicate_topics"
        key = self._cache_key(ctx, stage, domain)
        if hit := self._reuse(run_id, stage, domain, key):
            return hit["payload"]
        topics = self.cat.topics_for(domain)
        routed = [s for s in segments if domain in s["domains"]]
        must = sorted(c for c in lex if any(t["code"] == c for t in topics))
        block = stage_block(stage, domain=self.cat.domain(domain), topics=topics, segments=routed, must_consider=must)
        out = await self._call(run_id, ctx, stage, domain, block)
        out["domain"] = domain
        self.store.save_result(run_id, stage, domain, key, "ok", out,
                               V.validate_topic_flags(out, domain, ctx.turns_by_id, segments, self.cat))
        return out

    async def _stage_extract(self, run_id: str, ctx: CallContext, cand: dict) -> dict:
        stage, item = "extract_cit", cand["instance_id"]
        key = self._cache_key(ctx, stage, item, cand)
        if hit := self._reuse(run_id, stage, item, key):
            return hit["payload"]
        task = self.cat.task(cand["task_code"])
        block = stage_block(stage, task=task, candidate=cand, call_date=ctx.call_date)
        out = await self._call(run_id, ctx, stage, item, block)
        val = V.validate_extraction(out, ctx.turns_by_id, ctx.pmap, self.cat)
        self.store.save_result(run_id, stage, item, key, "ok", out, val)
        return out

    async def _stage_verify(self, run_id: str, ctx: CallContext, cand: dict, extraction: dict) -> dict:
        stage, item = "verify_cit", cand["instance_id"]
        key = self._cache_key(ctx, stage, item, extraction)
        if hit := self._reuse(run_id, stage, item, key):
            return hit["payload"]
        params = [{**p, "value_text": V.value_text(p.get("value"))} for p in extraction["params"]]
        block = stage_block(stage, task=self.cat.task(cand["task_code"]), instance_id=item, params=params)
        out = await self._call(run_id, ctx, stage, item, block)
        self.store.save_result(run_id, stage, item, key, "ok", out,
                               {"evidence": {v["param_code"]: V.check_evidence(v["evidence"], ctx.turns_by_id)
                                             for v in out["verdicts"]}})
        return out


def _now() -> str:
    from .store import now
    return now()


def run_sync(name: str, force: bool = False, **kw) -> str:
    return asyncio.run(Pipeline(**kw).run(name, force=force))

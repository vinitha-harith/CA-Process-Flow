"""Azure OpenAI client wrapper.

Modes
* live   - calls your Azure OpenAI gpt-5.1 deployment (Chat Completions, forced strict tool call).
           With LLM_RECORD=1 every response is also saved as a replay fixture.
* replay - reads responses from data/fixtures/<transcript>/<stage>__<item>.json (offline demo/tests).

Every call: egress guard -> request -> usage logging (incl. cached_tokens and the prefix hash).
"""
from __future__ import annotations

import json
import logging
import random
import threading
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

from .config import Settings, get_settings
from .pseudo import egress_guard, mask_types
from .store import Store

log = logging.getLogger("poc.llm")


class LlmError(RuntimeError):
    pass


class FixtureMissing(LlmError):
    pass


@dataclass
class Usage:
    input_tokens: int = 0
    cached_tokens: int = 0
    output_tokens: int = 0
    reasoning_tokens: int = 0
    estimated: bool = False


@dataclass
class LlmResult:
    args: dict
    usage: Usage
    latency_ms: int
    prefix_sha: str


def _estimate_tokens(text: str) -> int:
    return max(1, len(text) // 4)


class LlmClient:
    def __init__(self, settings: Settings | None = None, store: Store | None = None):
        self.s = settings or get_settings()
        self.store = store
        self._client = None
        self.disabled: set[str] = set()      # capabilities the endpoint rejected (auto-detected)
        self._sem = threading.Semaphore(self.s.max_concurrency)
        if not self.s.send_cache_key:
            self.disabled.add("prompt_cache_key")

    # --- client construction -----------------------------------------------------
    def client(self):
        if self._client is not None:
            return self._client
        try:
            from openai import AzureOpenAI, OpenAI
        except ImportError as e:  # pragma: no cover
            raise LlmError("pip install openai (>=1.108) to use LLM_MODE=live") from e
        s = self.s
        headers = dict(s.extra_headers)
        if s.auth == "entra":
            from azure.identity import DefaultAzureCredential, get_bearer_token_provider
            token = get_bearer_token_provider(DefaultAzureCredential(), "https://cognitiveservices.azure.com/.default")
            if s.api_style == "legacy":
                self._client = AzureOpenAI(azure_endpoint=s.endpoint, azure_ad_token_provider=token,
                                           api_version=s.api_version, default_headers=headers,
                                           timeout=s.timeout_s, max_retries=0)
            else:
                base = s.base_url or f"{s.endpoint}/openai/v1/"
                self._client = OpenAI(base_url=base, api_key=token, default_headers=headers,
                                      timeout=s.timeout_s, max_retries=0)
        elif s.api_style == "legacy":
            self._client = AzureOpenAI(azure_endpoint=s.endpoint, api_key=s.api_key, api_version=s.api_version,
                                       default_headers=headers, timeout=s.timeout_s, max_retries=0)
        else:
            base = s.base_url if s.api_style == "custom" else f"{s.endpoint}/openai/v1/"
            if not base or base.startswith("/openai"):
                raise LlmError("Set AZURE_OPENAI_ENDPOINT (or AZURE_OPENAI_BASE_URL for api_style=custom)")
            if s.api_key:
                headers.setdefault("api-key", s.api_key)
            self._client = OpenAI(base_url=base, api_key=s.api_key or "unused", default_headers=headers,
                                  timeout=s.timeout_s, max_retries=0)
        return self._client

    # --- the one entry point used by the pipeline ---------------------------------
    def call_tool(self, *, run_id: str, stage: str, item_id: str, fixture_key: str, messages: list[dict],
                  tools: list[dict], tool_name: str, effort: str | None, max_out: int, cache_key: str | None,
                  prompt_version: str, prefix_sha: str, prefix_chars: int = 0, warm: bool = False) -> LlmResult:
        egress_guard(messages, mask_types(self.s.pseudonymize_types))
        t0 = time.time()
        try:
            if self.s.llm_mode == "replay":
                args, usage = self._replay(fixture_key, stage, item_id, messages, tools, prefix_chars, warm)
            else:
                args, usage = self._live(messages, tools, tool_name, effort, max_out, cache_key)
                if self.s.record:
                    self._record(fixture_key, stage, item_id, args, usage)
        except Exception as e:
            self._log(run_id, stage, item_id, prompt_version, effort, cache_key, prefix_sha, Usage(),
                      int((time.time() - t0) * 1000), "failed", str(e)[:500])
            raise
        latency = int((time.time() - t0) * 1000)
        self._log(run_id, stage, item_id, prompt_version, effort, cache_key, prefix_sha, usage, latency, "ok", None)
        return LlmResult(args, usage, latency, prefix_sha)

    # --- live --------------------------------------------------------------------
    def _kwargs(self, messages, tools, tool_name, effort, max_out, cache_key) -> dict:
        msgs = messages
        if "developer_role" in self.disabled:
            msgs = [{**m, "role": "system"} if m["role"] == "developer" else m for m in messages]
        kw: dict[str, Any] = dict(model=self.s.deployment, messages=msgs, tools=tools,
                                  tool_choice={"type": "function", "function": {"name": tool_name}},
                                  max_completion_tokens=max_out)
        if "parallel_tool_calls" not in self.disabled:
            kw["parallel_tool_calls"] = False
        if effort and "reasoning_effort" not in self.disabled:
            kw["reasoning_effort"] = effort
        if cache_key and "prompt_cache_key" not in self.disabled:
            kw["extra_body"] = {"prompt_cache_key": cache_key}
        return kw

    def _create(self, build) -> Any:
        import openai

        retryable = (openai.RateLimitError, openai.APITimeoutError, openai.APIConnectionError,
                     openai.InternalServerError)
        last: Exception | None = None
        for attempt in range(6):
            try:
                with self._sem:
                    return self.client().chat.completions.create(**build())
            except openai.BadRequestError as e:
                msg = str(e).lower()
                fixed = False
                for cap in ("prompt_cache_key", "reasoning_effort", "parallel_tool_calls"):
                    if cap in msg and cap not in self.disabled:
                        log.warning("Endpoint rejected %s - disabling it for this session", cap)
                        self.disabled.add(cap)
                        fixed = True
                if "developer" in msg and "developer_role" not in self.disabled:
                    log.warning("Endpoint rejected the developer role - using system instead")
                    self.disabled.add("developer_role")
                    fixed = True
                if not fixed:
                    raise LlmError(f"Bad request: {e}") from e
                last = e
            except retryable as e:
                last = e
                retry_after = None
                resp = getattr(e, "response", None)
                if resp is not None:
                    retry_after = resp.headers.get("retry-after") or resp.headers.get("retry-after-ms")
                wait = float(retry_after) if retry_after and str(retry_after).replace(".", "").isdigit() \
                    else min(60.0, 2 ** attempt * 2 + random.random())
                log.warning("Transient error (%s), retrying in %.1fs", type(e).__name__, wait)
                time.sleep(wait)
        raise LlmError(f"Giving up after retries: {last}")

    def _live(self, messages, tools, tool_name, effort, max_out, cache_key) -> tuple[dict, Usage]:
        resp = self._create(lambda: self._kwargs(messages, tools, tool_name, effort, max_out, cache_key))
        choice = resp.choices[0]
        calls = choice.message.tool_calls or []
        if choice.finish_reason == "length":
            raise LlmError(f"Output truncated at max_completion_tokens={max_out}; raise the stage's max_out")
        if not calls:
            raise LlmError(f"No tool call returned (finish_reason={choice.finish_reason}): "
                           f"{(choice.message.content or '')[:200]}")
        try:
            args = json.loads(calls[0].function.arguments)
        except json.JSONDecodeError as e:
            raise LlmError(f"Tool arguments are not valid JSON: {e}") from e
        return args, self._usage(resp)

    @staticmethod
    def _usage(resp) -> Usage:
        u = resp.usage
        ptd = getattr(u, "prompt_tokens_details", None)
        ctd = getattr(u, "completion_tokens_details", None)
        return Usage(input_tokens=u.prompt_tokens or 0,
                     cached_tokens=(getattr(ptd, "cached_tokens", 0) or 0) if ptd else 0,
                     output_tokens=u.completion_tokens or 0,
                     reasoning_tokens=(getattr(ctd, "reasoning_tokens", 0) or 0) if ctd else 0)

    def call_text(self, messages: list[dict], effort: str | None = "low", max_out: int = 16000) -> tuple[str, Usage]:
        """Free-text call (synthetic transcript generation, endpoint check). Live only."""
        def build():
            kw: dict[str, Any] = dict(model=self.s.deployment, messages=messages, max_completion_tokens=max_out)
            if effort and "reasoning_effort" not in self.disabled:
                kw["reasoning_effort"] = effort
            return kw
        resp = self._create(build)
        return resp.choices[0].message.content or "", self._usage(resp)

    # --- replay / record -----------------------------------------------------------
    def _fixture_path(self, fixture_key: str, stage: str, item_id: str) -> Path:
        safe = item_id.replace("/", "_")
        return self.s.fixtures_dir / fixture_key / f"{stage}__{safe}.json"

    def _replay(self, fixture_key, stage, item_id, messages, tools, prefix_chars, warm) -> tuple[dict, Usage]:
        path = self._fixture_path(fixture_key, stage, item_id)
        if not path.exists():
            raise FixtureMissing(f"No replay fixture {path.relative_to(self.s.fixtures_dir.parent.parent)}. "
                                 "Run once with LLM_MODE=live LLM_RECORD=1 to record it.")
        data = json.loads(path.read_text(encoding="utf-8"))
        if data.get("usage"):
            return data["args"], Usage(**data["usage"])
        # Estimated usage so the cost/cache view works offline (clearly flagged as estimated).
        total = _estimate_tokens(json.dumps(tools) + "".join(str(m["content"]) for m in messages))
        cached = (min(prefix_chars // 4, total) // 128) * 128 if warm else 0
        out = _estimate_tokens(json.dumps(data["args"]))
        reasoning = out
        return data["args"], Usage(total, cached, out + reasoning, reasoning, estimated=True)

    def _record(self, fixture_key, stage, item_id, args, usage: Usage) -> None:
        path = self._fixture_path(fixture_key, stage, item_id)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps({"args": args, "usage": asdict(usage)}, ensure_ascii=False, indent=2),
                        encoding="utf-8")

    # --- telemetry ------------------------------------------------------------------
    def _log(self, run_id, stage, item_id, prompt_version, effort, cache_key, prefix_sha, usage: Usage,
             latency, status, error) -> None:
        if not self.store:
            return
        self.store.log_llm_call(
            run_id=run_id, stage=stage, item_id=item_id, prompt_version=prompt_version,
            deployment=self.s.deployment, effort=effort, cache_key=cache_key, prefix_sha=prefix_sha,
            input_tokens=usage.input_tokens, cached_tokens=usage.cached_tokens, output_tokens=usage.output_tokens,
            reasoning_tokens=usage.reasoning_tokens, latency_ms=latency,
            cost_usd=round(self.s.cost(usage.input_tokens, usage.cached_tokens, usage.output_tokens), 6),
            status=status, error=error, estimated=int(usage.estimated))

"""Deterministic validation of every LLM output (no LLM involved).

* evidence quotes must exist in the cited turn (normalized, fuzzy >= 0.85)
* numbers in summary bullets must appear in the cited turns
* placeholders must exist in the transcript's placeholder map
* CIT parameters are type-checked against the catalog; real values (IBAN checksum,
  email syntax) are checked after re-hydration
"""
from __future__ import annotations

import re
import unicodedata
from difflib import SequenceMatcher

from .catalog import Catalog, param_required
from .pseudo import EMAIL_RE, PlaceholderMap, iban_valid, mask_types, norm_phone, pattern_spans
from .transcript import Turn, turn_num

PLACEHOLDER = re.compile(r"\[[A-Z]+_\d+\]")
NUMBER = re.compile(r"\d[\d'’.,]*\d|\d")
DATA_TYPE_TO_KIND = {"email": "email", "iban": "iban", "person": "person", "persons": "persons",
                     "phone": "phone", "address": "address", "date": "date", "amount": "amount",
                     "tristate": "tristate", "enum": "enum", "text": "text"}


def normalize(text: str) -> str:
    text = unicodedata.normalize("NFKD", text.lower())
    text = "".join(c for c in text if not unicodedata.combining(c))
    text = re.sub(r"[^\w\[\]]+", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def quote_score(quote: str, turn_text: str) -> float:
    q, t = normalize(quote), normalize(turn_text)
    if not q:
        return 0.0
    if q in t:
        return 1.0
    qw, tw = q.split(), t.split()
    if len(qw) > len(tw):
        return SequenceMatcher(None, q, t).ratio()
    best = 0.0
    for i in range(0, len(tw) - len(qw) + 1):
        best = max(best, SequenceMatcher(None, q, " ".join(tw[i:i + len(qw)])).ratio())
        if best >= 0.99:
            break
    return best


def check_evidence(evidence: list[dict], turns: dict[str, Turn], threshold: float = 0.85) -> list[str]:
    issues = []
    for e in evidence:
        t = turns.get(e.get("turn", ""))
        if t is None:
            issues.append(f"cited turn {e.get('turn')} does not exist")
        elif quote_score(e.get("quote", ""), t.text) < threshold:
            issues.append(f"quote not found in {e['turn']}: \"{e.get('quote', '')[:60]}\"")
    return issues


def numbers_in(text: str) -> set[str]:
    out = set()
    for m in NUMBER.findall(PLACEHOLDER.sub(" ", text)):
        digits = re.sub(r"\D", "", m)
        if digits and not re.fullmatch(r"T\d+", m):
            out.add(digits.lstrip("0") or "0")
    return out


def turn_numbers(text: str) -> set[str]:
    """Numbers in a turn, including IBANs/phones read out digit by digit (unmasked mode)."""
    out = numbers_in(text)
    for s in pattern_spans(text):
        digits = re.sub(r"\D", "", s.canonical.split("|")[-1])
        if digits:
            out.add(digits.lstrip("0") or "0")
            if s.etype == "PHONE" and s.canonical.startswith("0"):
                out.add("41" + s.canonical[1:])
    return out


def _turn_in_range(tid: str, seg: dict) -> bool:
    return turn_num(seg["turn_start"]) <= turn_num(tid) <= turn_num(seg["turn_end"])


# --- summary ------------------------------------------------------------------------
def validate_summary(summary: dict, turns: dict[str, Turn], segments: list[dict], pmap: PlaceholderMap,
                     catalog: Catalog) -> dict:
    """Returns {"issues": [...], "bullets": {"<section_idx>.<bullet_idx>": [issues]}}."""
    seg_by_id = {s["segment_id"]: s for s in segments}
    max_words = catalog.guidelines.get("max_words_per_bullet", 30)
    out: dict = {"issues": [], "bullets": {}}

    def check_bullet(key: str, b: dict, seg: dict | None) -> None:
        issues = []
        cited = [turns[t] for t in b.get("turns", []) if t in turns]
        missing = [t for t in b.get("turns", []) if t not in turns]
        if missing:
            issues.append(f"cites missing turns {missing}")
        if not b.get("turns"):
            issues.append("no citation")
        if seg and any(not _turn_in_range(t, seg) for t in b.get("turns", []) if t in turns):
            issues.append(f"cites turns outside segment {seg['segment_id']}")
        cited_numbers = set().union(*(turn_numbers(t.text) for t in cited)) if cited else set()
        unsupported = numbers_in(b["text"]) - cited_numbers
        if unsupported:
            issues.append(f"number(s) not in cited turns: {sorted(unsupported)}")
        unknown = set(PLACEHOLDER.findall(b["text"])) - pmap.tokens
        if unknown:
            issues.append(f"unknown placeholders {sorted(unknown)}")
        if len(b["text"].split()) > max_words + 5:
            issues.append(f"bullet longer than {max_words} words")
        if issues:
            out["bullets"][key] = issues

    check_bullet("purpose", summary["purpose"], None)
    seen_codes = []
    for i, sec in enumerate(summary.get("sections", [])):
        rule = catalog.section(sec["section_code"])
        if rule is None:
            out["issues"].append(f"unknown section {sec['section_code']}")
            continue
        seen_codes.append(sec["section_code"])
        if len(sec["bullets"]) > rule["max_bullets"]:
            out["issues"].append(f"{sec['section_code']}: {len(sec['bullets'])} bullets > cap {rule['max_bullets']}")
        seg = seg_by_id.get(sec.get("segment_id") or "")
        for j, b in enumerate(sec["bullets"]):
            check_bullet(f"{i}.{j}", b, seg if sec["section_code"] == "discussion" else None)
    return out


# --- CIT ----------------------------------------------------------------------------
def validate_candidates(cands: dict, turns: dict[str, Turn], catalog: Catalog) -> dict:
    out = {}
    for c in cands.get("candidates", []):
        issues = check_evidence(c.get("evidence", []), turns)
        if catalog.task(c["task_code"]) is None:
            issues.append(f"unknown task {c['task_code']}")
        out[c["instance_id"]] = issues
    return out


def value_text(value: dict | None) -> str:
    if not value:
        return "—"
    v = value.get("value")
    if value.get("kind") == "amount":
        return f"{value.get('currency')} {v:,.2f}" if isinstance(v, (int, float)) else str(v)
    if isinstance(v, list):
        return ", ".join(v)
    return str(v)


def validate_extraction(ext: dict, turns: dict[str, Turn], pmap: PlaceholderMap, catalog: Catalog) -> dict:
    """Returns {"status": ok|incomplete|invalid, "params": {code: [issues]}, "issues": [...]}."""
    task = catalog.task(ext["task_code"])
    mask = mask_types()
    result = {"status": "ok", "params": {}, "issues": []}
    if task is None:
        return {"status": "invalid", "params": {}, "issues": [f"unknown task {ext['task_code']}"]}
    by_code = {p["param_code"]: p for p in ext.get("params", [])}
    values = {c: (p.get("value") or {}).get("value") for c, p in by_code.items()}
    for unknown in set(by_code) - {p["code"] for p in task["params"]}:
        result["issues"].append(f"unknown parameter {unknown}")
    for spec in task["params"]:
        code, issues = spec["code"], []
        p = by_code.get(code)
        required = param_required(spec, values)
        if p is None or p.get("status") == "not_stated" or not p.get("value"):
            if required:
                issues.append("required but not stated")
                result["status"] = "incomplete" if result["status"] == "ok" else result["status"]
            if issues:
                result["params"][code] = issues
            continue
        value = p["value"]
        expected = DATA_TYPE_TO_KIND[spec["data_type"]]
        if value.get("kind") != expected:
            issues.append(f"value kind {value.get('kind')} != expected {expected}")
        if spec.get("enum_values") and value.get("kind") == "enum" and value.get("value") not in spec["enum_values"]:
            issues.append(f"'{value.get('value')}' not in {spec['enum_values']}")
        issues += check_value(value, p.get("evidence", []), turns, pmap, mask)
        issues += check_evidence(p.get("evidence", []), turns)
        speaker = spec.get("source_speaker", "ANY")
        if speaker != "ANY" and p.get("evidence"):
            speakers = {turns[e["turn"]].speaker for e in p["evidence"] if e["turn"] in turns}
            if speakers and speaker not in speakers:
                issues.append(f"must be stated by {speaker}; evidence is from {sorted(speakers)}")
        if p.get("status") == "conflicting":
            issues.append("conflicting statements in the call - CA must decide")
        if issues:
            result["params"][code] = issues
            if result["status"] == "ok" and any(k in i for i in issues
                                                for k in ("kind", "not in", "checksum", "syntax", "leak", "differs")):
                result["status"] = "invalid"
    return result


KIND_ETYPE = {"iban": "IBAN", "email": "EMAIL", "person": "PERSON", "persons": "PERSON", "phone": "PHONE",
              "address": "ADDR"}


def _norm(etype: str, v: str) -> str:
    if etype == "IBAN":
        return re.sub(r"\s", "", v).upper()
    if etype == "EMAIL":
        return v.strip().lower()
    if etype == "PHONE":
        return norm_phone(v)
    return v.strip()


def check_value(value: dict, evidence: list[dict], turns: dict[str, Turn], pmap: PlaceholderMap,
                mask: frozenset[str]) -> list[str]:
    """Client-data value checks that depend on whether the type is masked."""
    etype = KIND_ETYPE.get(value.get("kind", ""))
    if not etype:
        return []
    raw = value.get("value")
    items = raw if isinstance(raw, list) else [raw]
    issues: list[str] = []
    for v in items:
        v = str(v or "")
        is_ph = bool(PLACEHOLDER.fullmatch(v))
        if etype in mask:                       # placeholder expected
            if not is_ph:
                issues.append(f"raw {etype.lower()} value although {etype} is masked - possible leak")
            elif v not in pmap.tokens:
                issues.append(f"placeholder {v} not in this transcript")
            else:
                real = pmap.value(v) or ""
                if etype == "IBAN" and not iban_valid(real):
                    issues.append("IBAN checksum fails after re-hydration")
                if etype == "EMAIL" and not EMAIL_RE.fullmatch(real):
                    issues.append("email syntax invalid after re-hydration")
            continue
        if is_ph:                               # real value expected
            issues.append(f"placeholder {v} returned although {etype} is not masked")
            continue
        if etype == "IBAN" and not iban_valid(v):
            issues.append(f"IBAN checksum fails ({v[:4]}...) - possibly misheard digits; check with the client")
        if etype == "EMAIL" and not EMAIL_RE.fullmatch(v):
            issues.append("email syntax invalid")
        if etype == "PHONE" and not 9 <= len(re.sub(r"\D", "", v)) <= 13:
            issues.append("phone number has an implausible length")
        if etype in ("IBAN", "EMAIL", "PHONE"):
            # deterministic second reading of the cited turns (spoken digits, "dot"/"at" etc.)
            seen = {_norm(etype, s.canonical) for e in evidence if e.get("turn") in turns
                    for s in pattern_spans(turns[e["turn"]].text) if s.etype == etype}
            if seen and _norm(etype, v) not in seen:
                issues.append(f"value differs from the deterministic reading of the cited turn ({sorted(seen)[0]})")
    return issues


# --- topics -------------------------------------------------------------------------------
def validate_topic_flags(flags: dict, domain: str, turns: dict[str, Turn], segments: list[dict],
                         catalog: Catalog) -> dict:
    allowed = {t["code"] for t in catalog.topics_for(domain)}
    seg_ids = {s["segment_id"] for s in segments}
    out = {}
    for f in flags.get("flags", []):
        issues = check_evidence(f.get("evidence", []), turns)
        if f["topic_code"] not in allowed:
            issues.append(f"topic {f['topic_code']} not in domain {domain}")
        if not f.get("evidence"):
            issues.append("no evidence")
        bad = [s for s in f.get("segment_ids", []) if s not in seg_ids]
        if bad:
            issues.append(f"unknown segments {bad}")
        out[f["topic_code"]] = issues
    return out


# --- reconciliation ---------------------------------------------------------------------
def reconcile(summary: dict | None, candidates: dict | None, tolerance: int = 3) -> list[str]:
    """Summary client_instructions vs detected CITs: two independent recall checks."""
    if not summary or not candidates:
        return []
    active = [c for c in candidates.get("candidates", []) if c["status"] in ("requested", "confirmed")]
    cit_turns = {c["instance_id"]: {turn_num(e["turn"]) for e in c["evidence"]} for c in active}
    issues = []
    instr = [b for s in summary["sections"] if s["section_code"] == "client_instructions" for b in s["bullets"]]
    for b in instr:
        bt = {turn_num(t) for t in b["turns"]}
        if not any(abs(x - y) <= tolerance for ts in cit_turns.values() for x in ts for y in bt):
            issues.append(f"Summary instruction without a detected task: \"{b['text'][:80]}\" ({', '.join(b['turns'])})")
    for cid, ts in cit_turns.items():
        if not any(abs(x - turn_num(t)) <= tolerance for b in instr for t in b["turns"] for x in ts):
            task = next(c["task_code"] for c in active if c["instance_id"] == cid)
            issues.append(f"Detected task {cid} ({task}) has no matching bullet in client_instructions")
    return issues

"""Business catalogs (YAML in the PoC, Postgres tables in production).

Catalogs are data: task types, topics, summary guidelines and edit actions are
rendered into prompts at run time, so changing them needs no code change.
"""
from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Any

import yaml

from .config import get_settings

FILES = ("domains.yaml", "topics.yaml", "cit_tasks.yaml", "summary_guidelines.yaml", "edit_actions.yaml")


@dataclass
class Catalog:
    domains: list[dict]
    topics: list[dict]
    tasks: list[dict]
    guidelines: dict
    edit_actions: list[dict]
    version_hash: str

    # --- lookups -------------------------------------------------------------
    @property
    def domain_codes(self) -> list[str]:
        return [d["code"] for d in self.domains]

    @property
    def regulatory_domains(self) -> set[str]:
        return {d["code"] for d in self.domains if d.get("regulatory")}

    def domain(self, code: str) -> dict:
        return next(d for d in self.domains if d["code"] == code)

    def topics_for(self, domain: str) -> list[dict]:
        return sorted((t for t in self.topics if t["domain"] == domain), key=lambda t: t["code"])

    def topic(self, code: str) -> dict | None:
        return next((t for t in self.topics if t["code"] == code), None)

    @property
    def task_codes(self) -> list[str]:
        return [t["code"] for t in self.tasks]

    def task(self, code: str) -> dict | None:
        return next((t for t in self.tasks if t["code"] == code), None)

    @property
    def section_codes(self) -> list[str]:
        return [s["code"] for s in self.guidelines["sections"]]

    def section(self, code: str) -> dict | None:
        return next((s for s in self.guidelines["sections"] if s["code"] == code), None)

    def edit_action(self, code: str) -> dict | None:
        return next((a for a in self.edit_actions if a["code"] == code), None)

    def enums(self) -> dict[str, list[str]]:
        """Closed sets injected into tool schemas so Azure enforces them while generating."""
        return {"domain": self.domain_codes, "task": self.task_codes, "section": self.section_codes}


def load_catalog(directory: Path | None = None) -> Catalog:
    directory = directory or get_settings().catalogs_dir
    raw: dict[str, Any] = {}
    h = hashlib.sha256()
    for name in FILES:
        text = (directory / name).read_text(encoding="utf-8")
        h.update(text.encode())
        raw[name] = yaml.safe_load(text)
    return Catalog(
        domains=raw["domains.yaml"]["domains"],
        topics=raw["topics.yaml"]["topics"],
        tasks=raw["cit_tasks.yaml"]["tasks"],
        guidelines=raw["summary_guidelines.yaml"],
        edit_actions=raw["edit_actions.yaml"]["actions"],
        version_hash=h.hexdigest()[:12],
    )


@lru_cache(maxsize=1)
def get_catalog() -> Catalog:
    return load_catalog()


_REQ = re.compile(r"^\s*(\w+)\s+in\s+\[([^\]]*)\]\s*$")


def param_required(param: dict, values: dict[str, Any]) -> bool:
    """Evaluate a parameter's `required` rule: true/false or "<param> in [a, b]"."""
    rule = param.get("required", True)
    if isinstance(rule, bool):
        return rule
    m = _REQ.match(str(rule))
    if not m:
        return True
    other, options = m.group(1), {o.strip() for o in m.group(2).split(",")}
    return str(values.get(other)) in options

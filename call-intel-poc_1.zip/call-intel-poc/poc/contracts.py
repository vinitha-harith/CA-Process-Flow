"""Output contracts for every LLM call (Pydantic v2).

Two layers of enforcement:
* Azure strict tool schemas enforce types, required fields and enums while the
  model generates (see schema.py; catalog enums are injected via `x-enum`).
* Pydantic enforces the regex patterns Azure does not support (turn IDs, ISO dates)
  when the output is parsed; client-data formats are checked in validate.py.
"""
from __future__ import annotations

from typing import Annotated, Literal, Union

from pydantic import BaseModel, Field, StringConstraints

# --- shared atoms -------------------------------------------------------------
TurnId = Annotated[str, StringConstraints(pattern=r"^T\d{3,4}$")]
SegmentId = Annotated[str, StringConstraints(pattern=r"^S\d{2}$")]
DomainCode = Annotated[str, Field(json_schema_extra={"x-enum": "domain"})]
TaskCode = Annotated[str, Field(json_schema_extra={"x-enum": "task"})]
SectionCode = Annotated[str, Field(json_schema_extra={"x-enum": "section"})]

# Client-data values: a placeholder ([IBAN_1]) when that type is masked, else the real value
# in normalized form. Which one is required depends on PSEUDONYMIZE_TYPES, so the format is
# checked in validate.py (placeholder exists / IBAN checksum / email syntax / cross-check with
# the deterministic reading of the cited turn), not by a fixed regex here.
IbanStr = Annotated[str, Field(description="Placeholder like [IBAN_1] if shown so; else the IBAN, uppercase, no spaces")]
EmailStr = Annotated[str, Field(description="Placeholder like [EMAIL_1] if shown so; else name@domain, lowercase")]
PersonStr = Annotated[str, Field(description="Placeholder like [PERSON_2] if shown so; else the name as stated")]
PhoneStr = Annotated[str, Field(description="Placeholder like [PHONE_1] if shown so; else international format +41...")]
AddrStr = Annotated[str, Field(description="Placeholder like [ADDR_1] if shown so; else street, number, postcode, town")]
IsoDate = Annotated[str, StringConstraints(pattern=r"^\d{4}-\d{2}-\d{2}$")]

Phase = Literal["opening", "needs_and_situation", "advice", "administration", "closing"]
Signal = Literal["instruction", "consent_discussion", "complaint", "product_mention",
                 "risk_disclosure", "cancellation"]


class Evidence(BaseModel):
    turn: TurnId = Field(description="Turn ID where the evidence is, e.g. T042")
    quote: str = Field(description="Verbatim quote from that turn, max 25 words, original language")


# --- Stage 1: conversation map ----------------------------------------------
class Segment(BaseModel):
    segment_id: str = Field(description="S01, S02, ... in order")
    phase: Phase
    turn_start: TurnId
    turn_end: TurnId
    title: str = Field(description="At most 8 words, in the requested language")
    gist: str = Field(description="At most 40 words, factual, placeholders copied exactly")
    initiated_by: Literal["CLIENT", "CA", "MIXED"]
    domains: list[DomainCode]
    signals: list[Signal]


class ConversationMap(BaseModel):
    call_purpose: str
    segments: list[Segment]


# --- Stage 2a: summary -------------------------------------------------------
class Bullet(BaseModel):
    text: str
    turns: list[TurnId] = Field(description="1-3 turn IDs that support this bullet")
    speaker_basis: Literal["CLIENT", "CA", "BOTH"]


class SummarySection(BaseModel):
    section_code: SectionCode
    segment_id: str | None = Field(description="Map segment this block covers (discussion blocks), else null")
    heading: str | None = Field(description="Short heading for discussion blocks, else null")
    bullets: list[Bullet]


class Summary(BaseModel):
    language: str
    purpose: Bullet
    sections: list[SummarySection]


class SectionPatch(BaseModel):
    """Output of a section-scoped edit."""
    section_code: SectionCode
    segment_id: str | None
    heading: str | None
    bullets: list[Bullet]


# --- Stage 2b: CIT detection -------------------------------------------------
class CitCandidate(BaseModel):
    instance_id: str = Field(description="C1, C2, ...")
    task_code: TaskCode
    status: Literal["requested", "confirmed", "cancelled", "mentioned_only"]
    initiated_by: Literal["CLIENT", "CA"]
    client_agreement_turn: TurnId | None
    evidence: list[Evidence]
    confidence: float
    rationale: str


class CitCandidates(BaseModel):
    candidates: list[CitCandidate]


# --- Stage 3: CIT extraction (generic envelope; per-task typing checked in code)
class IbanValue(BaseModel):
    kind: Literal["iban"]
    value: IbanStr


class EmailValue(BaseModel):
    kind: Literal["email"]
    value: EmailStr


class PersonValue(BaseModel):
    kind: Literal["person"]
    value: PersonStr


class PersonsValue(BaseModel):
    kind: Literal["persons"]
    value: list[PersonStr]


class PhoneValue(BaseModel):
    kind: Literal["phone"]
    value: PhoneStr


class AddressValue(BaseModel):
    kind: Literal["address"]
    value: AddrStr


class DateValue(BaseModel):
    kind: Literal["date"]
    value: IsoDate


class AmountValue(BaseModel):
    kind: Literal["amount"]
    value: float
    currency: Literal["CHF", "EUR", "USD", "GBP", "OTHER"]


class TriValue(BaseModel):
    kind: Literal["tristate"]
    value: Literal["yes", "no", "not_discussed"]


class EnumValue(BaseModel):
    kind: Literal["enum"]
    value: str


class TextValue(BaseModel):
    kind: Literal["text"]
    value: str


ParamValue = Union[IbanValue, EmailValue, PersonValue, PersonsValue, PhoneValue, AddressValue,
                   DateValue, AmountValue, TriValue, EnumValue, TextValue]


class ParamResult(BaseModel):
    param_code: str
    status: Literal["stated", "not_stated", "conflicting", "unclear"]
    value: ParamValue | None
    evidence: list[Evidence]


class CitExtraction(BaseModel):
    task_code: TaskCode
    instance_id: str
    params: list[ParamResult]


# --- Stage 4: verification of high-risk extractions ---------------------------
class ParamVerdict(BaseModel):
    param_code: str
    verdict: Literal["agree", "disagree", "cannot_tell"]
    corrected_value: str | None
    evidence: list[Evidence]
    note: str


class Verification(BaseModel):
    instance_id: str
    verdicts: list[ParamVerdict]


# --- Stage 2c: topic adjudication -------------------------------------------
class TopicFlag(BaseModel):
    topic_code: str
    level: Literal["mentioned", "discussed", "action_agreed"]
    segment_ids: list[str]
    evidence: list[Evidence]
    confidence: float


class TopicFlags(BaseModel):
    domain: DomainCode
    flags: list[TopicFlag]


# --- Navigator ------------------------------------------------------------------
class SegmentPick(BaseModel):
    segment_id: str
    reason: str


class NavResult(BaseModel):
    picks: list[SegmentPick] = Field(description="0-3 segments; empty if nothing matches")


# Tool name -> output model. ORDER MATTERS: the list is identical in every
# transcript-family call so the cached prefix is identical.
TRANSCRIPT_TOOLS: list[tuple[str, type[BaseModel], str]] = [
    ("emit_conversation_map", ConversationMap, "Outline of the call: phases, segments, domains."),
    ("emit_summary", Summary, "Structured summary of the call following the guidelines."),
    ("emit_cit_candidates", CitCandidates, "Client-induced task candidates detected in the call."),
    ("emit_cit_extraction", CitExtraction, "Parameters extracted for one detected task instance."),
    ("emit_topic_flags", TopicFlags, "Topics of one domain that the call touches, with evidence."),
    ("emit_verification", Verification, "Independent check of one task instance's extracted parameters."),
]
TOOL_MODELS: dict[str, type[BaseModel]] = {n: m for n, m, _ in TRANSCRIPT_TOOLS}
TOOL_MODELS.update({"emit_section_patch": SectionPatch, "emit_summary_edit": Summary,
                    "pick_segments": NavResult})

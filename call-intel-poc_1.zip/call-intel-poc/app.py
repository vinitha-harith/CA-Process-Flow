"""Call Intelligence PoC - CA review UI.   Run:  streamlit run app.py"""
from __future__ import annotations

import asyncio
import html
import json
import re

import pandas as pd
import streamlit as st

from poc.catalog import get_catalog
from poc.config import get_settings
from poc.edits import apply_edit
from poc.llm import LlmClient
from poc.pipeline import Pipeline, load_context
from poc.pseudo import EgressBlocked, PlaceholderMap, egress_guard, guarded_types
from poc.store import Store
from poc.transcript import turn_num
from poc.validate import value_text

st.set_page_config(page_title="Call Intelligence PoC", layout="wide")
S = get_settings()
CAT = get_catalog()
PH = re.compile(r"\[[A-Z]+_\d+\]")


@st.cache_resource
def get_store() -> Store:
    return Store()


store = get_store()

# --- sidebar --------------------------------------------------------------------------
with st.sidebar:
    st.header("Call Intelligence PoC")
    mode_label = "LIVE - Azure OpenAI" if S.llm_mode == "live" else "REPLAY - offline fixtures"
    st.caption(f"Mode: **{mode_label}**  \nDeployment: `{S.deployment}`")
    names = sorted(p.stem for p in S.transcripts_dir.glob("*.txt"))
    name = st.selectbox("Transcript", names)
    force = st.checkbox("Ignore cached stage results", value=False)
    if st.button("Run pipeline", type="primary", use_container_width=True):
        with st.spinner("Pseudonymize -> map -> summary | tasks | topics -> extract -> verify ..."):
            try:
                rid = asyncio.run(Pipeline(store=store).run(name, force=force))
                st.session_state["run_id"] = rid
                st.session_state.pop("last_edit", None)
            except Exception as e:  # shown to the user, logged in the run row
                st.error(f"Run failed: {e}")
    runs = store.runs(name)
    run_labels = {r["run_id"]: f"{r['started_at'][5:16]}  {r['status']}  ({r['mode']})" for r in runs}
    default = st.session_state.get("run_id")
    run_id = st.selectbox("Run", list(run_labels), format_func=lambda r: run_labels[r],
                          index=list(run_labels).index(default) if default in run_labels else 0) if runs else None
    reveal = st.toggle("Show real values (re-hydrate)", value=False,
                       help="Re-hydration happens locally in the UI, never in a prompt.")
    st.caption(f"Masking: `{S.pseudonymize_types}` (PSEUDONYMIZE_TYPES). Synthetic data only.")

if not run_id:
    st.info("Pick a transcript and click **Run pipeline**. In replay mode `call_001_en` runs fully offline.")
    st.stop()

run = store.run(run_id)
ctx = load_context(store, run["transcript"])
pmap: PlaceholderMap = ctx.pmap
turns = ctx.turns_by_id
segments = store.segments(run_id)
routing_info = json.loads(run["domains_json"] or "{}")


def fmt(text: str) -> str:
    """HTML: placeholders highlighted, or re-hydrated when the toggle is on."""
    if text is None:
        return ""
    if reveal:
        return html.escape(pmap.rehydrate(text))
    return hl(text)


def hl(text: str) -> str:
    """HTML with placeholders highlighted (always - this is what the LLM saw)."""
    return PH.sub(lambda m: f"<code style='background:#e7f1fb;color:#1f4e79'>{m.group()}</code>", html.escape(text))


def plain(text: str) -> str:
    return pmap.rehydrate(text) if reveal else text


def show_turns(ids: list[str]) -> None:
    for tid in sorted(set(ids), key=turn_num):
        t = turns.get(tid)
        if t:
            st.markdown(f"<small><b>{tid} {t.speaker}</b>: {fmt(t.text)}</small>", unsafe_allow_html=True)


def result(stage: str, item: str = "-") -> dict | None:
    return store.result(run_id, stage, item)


cands = (result("detect_cits") or {}).get("payload") or {"candidates": []}
topic_results = [r for r in store.results(run_id, "adjudicate_topics") if r["status"] == "ok"]
calls = store.llm_calls(run_id)
publish = (result("publish") or {}).get("payload") or {}

# --- header ------------------------------------------------------------------------------
st.subheader(f"{run['transcript']}  ·  run {run_id}  ·  {run['status']}")
if run.get("error"):
    st.warning(f"Partial run - failed items: {run['error']}")
m = st.columns(6)
m[0].metric("Turns", len(ctx.turns))
m[1].metric("Segments", len(segments))
m[2].metric("Client tasks", sum(c["status"] in ("requested", "confirmed") for c in cands["candidates"]))
m[3].metric("Topic flags", sum(len(r["payload"]["flags"]) for r in topic_results))
ok_calls = [c for c in calls if c["status"] == "ok"]
m[4].metric("LLM cost (USD)", f"{sum(c['cost_usd'] for c in ok_calls):.3f}")
tin = sum(c["input_tokens"] for c in ok_calls)
m[5].metric("Cached input", f"{100 * sum(c['cached_tokens'] for c in ok_calls) / max(tin, 1):.0f}%")

tabs = st.tabs(["1 · Privacy", "2 · Outline", "3 · Summary", "4 · Client tasks", "5 · Topics", "6 · Cost & cache"])

# --- 1 privacy ------------------------------------------------------------------------
with tabs[0]:
    tx_row = store.transcript(run["transcript"]) or {}
    run_mask = [m for m in (tx_row.get("mask") or "").split(",") if m]
    if not run_mask:
        st.warning("Pseudonymization is **off** for this transcript (PSEUDONYMIZE_TYPES=none): the model receives "
                   "client data as spoken. Use only where compliance has approved it for this deployment.")
    elif set(run_mask) >= {"PERSON", "EMAIL", "IBAN", "PHONE", "ADDR"}:
        st.markdown("All client identifiers are replaced **before** any LLM call. The mapping stays on this machine.")
    else:
        st.info(f"Selective masking: only **{', '.join(run_mask)}** are replaced; everything else reaches the model "
                "as spoken, so the tasks can carry real values.")
    c1, c2 = st.columns(2)
    with c1:
        st.markdown("**Raw transcript**" + (" (never sent)" if run_mask else ""))
        with st.container(height=420):
            for t in ctx.turns:
                st.markdown(f"<small><b>{t.turn_id} {t.speaker}</b>: {html.escape(t.text_raw)}</small>",
                            unsafe_allow_html=True)
    with c2:
        st.markdown("**What the LLM sees**")
        with st.container(height=420):
            for t in ctx.turns:
                st.markdown(f"<small><b>{t.turn_id} {t.speaker}</b>: {hl(t.text)}</small>",
                            unsafe_allow_html=True)
    st.markdown("**Identifiers detected** - and whether they reached the model")
    st.dataframe([{"turn": d["turn"], "type": d["etype"], "as spoken": d["surface"] if reveal or not d["masked"] else "•••",
                   "normalized": d["value"] if reveal or not d["masked"] else "•••",
                   "sent to model as": "placeholder" if d["masked"] else "real value", "source": d["source"]}
                  for d in tx_row.get("detections", [])],
                 use_container_width=True, hide_index=True)
    if pmap.entries:
        st.markdown("**Placeholder map** (local only)")
        st.dataframe([{"placeholder": e["token"], "type": e["etype"], "source": e["source"], "occurrences": e["count"],
                       "value": e["value"] if reveal else "•" * min(len(e["value"]), 12)} for e in pmap.entries],
                     use_container_width=True, hide_index=True)
    guard = sorted(guarded_types(frozenset(run_mask)))
    st.markdown("**Egress guard** - every prompt is re-scanned before it leaves the machine. "
                + (f"Active for: {', '.join(guard)}." if guard else "Inactive: no guarded type is masked."))
    probe = st.text_input("Try to send this text to the LLM", "Please pay it to CH93 0076 2011 6238 5295 7, thanks.")
    if st.button("Test egress guard"):
        try:
            egress_guard([{"role": "user", "content": probe}], frozenset(run_mask))
            st.success("No raw identifiers found - this prompt would be sent.")
        except EgressBlocked as e:
            st.error(f"Blocked: {e}")

# --- 2 outline ---------------------------------------------------------------------------
with tabs[1]:
    purpose = ((result("build_conversation_map") or {}).get("payload") or {}).get("call_purpose", "")
    if run.get("map_fallback"):
        st.warning("The LLM map was unusable twice - deterministic fallback outline in use.")
    if purpose:
        st.markdown(f"**Call purpose:** {fmt(purpose)}", unsafe_allow_html=True)
    st.dataframe([{"segment": s["segment_id"], "phase": f"{s['phase_id']} {s['phase']}",
                   "turns": f"{s['turn_start']}–{s['turn_end']}", "title": plain(s["title"]),
                   "gist": plain(s["gist"]), "domains": ", ".join(s["domains"]),
                   "signals": ", ".join(s["signals"])} for s in segments],
                 use_container_width=True, hide_index=True)
    pick = st.selectbox("Open segment", [s["segment_id"] for s in segments],
                        format_func=lambda sid: f"{sid} · {next(s['title'] for s in segments if s['segment_id'] == sid)}")
    seg = next((s for s in segments if s["segment_id"] == pick), None)
    if seg:
        a, b = turn_num(seg["turn_start"]), turn_num(seg["turn_end"])
        show_turns([t.turn_id for t in ctx.turns if a <= t.idx <= b])
    st.markdown("**Find in this call** (navigator: full-text search first, LLM over the outline only if needed)")
    hint = st.text_input("Hint", "the part about e-banking for his wife")
    if st.button("Locate"):
        from poc.navigator import locate_segments
        nav = locate_segments(store, LlmClient(store=store), run_id, ctx.fixture_key, hint)
        st.write(f"Method: **{nav.method}** → {nav.segment_ids or 'no match'}")
        if nav.fts:
            st.caption("Full-text ranks: " + ", ".join(f"{h['segment_id']}={h['rank']:.2f}" for h in nav.fts))

# --- 3 summary -----------------------------------------------------------------------
with tabs[2]:
    versions = store.summary_versions(run_id)
    if not versions:
        st.info("No summary in this run.")
    else:
        recon = publish.get("reconciliation") or []
        for r in recon:
            st.warning(f"Cross-check: {plain(r)}")
        labels = {v["id"]: f"v{i + 1} · {v['action_code']}" + (f" {v['action_params']}" if v["action_params"] else "")
                  for i, v in enumerate(versions)}
        vid = st.selectbox("Version", list(labels), index=len(labels) - 1, format_func=lambda v: labels[v])
        ver = next(v for v in versions if v["id"] == vid)
        summ, val = ver["content"], ver.get("validation") or {"bullets": {}, "issues": []}
        left, right = st.columns([3, 2])
        with left:
            st.markdown(f"**Purpose.** {fmt(summ['purpose']['text'])} "
                        f"<small style='color:#888'>[{', '.join(summ['purpose']['turns'])}]</small>",
                        unsafe_allow_html=True)
            for issue in val.get("issues", []):
                st.warning(issue)
            for i, sec in enumerate(summ["sections"]):
                rule = CAT.section(sec["section_code"]) or {"title": sec["section_code"]}
                title = rule["title"] + (f" · {sec['heading']}" if sec.get("heading") else "")
                st.markdown(f"**{title}**")
                if not sec["bullets"]:
                    st.caption("—")
                for j, b in enumerate(sec["bullets"]):
                    flag = val.get("bullets", {}).get(f"{i}.{j}")
                    warn = f" <span title='{html.escape('; '.join(flag))}'>⚠️</span>" if flag else ""
                    st.markdown(f"- {fmt(b['text'])} <small style='color:#888'>[{', '.join(b['turns'])}]</small>{warn}",
                                unsafe_allow_html=True)
                    if flag:
                        st.caption("Check: " + "; ".join(flag))
                with st.expander("Cited turns", expanded=False):
                    show_turns([t for b in sec["bullets"] for t in b["turns"]])
        with right:
            st.markdown("**Edit with a predefined action**")
            sec_labels = [f"{i}: {(CAT.section(s['section_code']) or {}).get('title', s['section_code'])}"
                          + (f" · {s['heading']}" if s.get("heading") else "") for i, s in enumerate(summ["sections"])]
            action = st.selectbox("Action", [a["code"] for a in CAT.edit_actions],
                                  format_func=lambda c: CAT.edit_action(c)["label"]["en"])
            spec = CAT.edit_action(action)
            sec_idx = None
            if spec["scope"] == "section":
                sec_idx = st.selectbox("Section", range(len(sec_labels)), format_func=lambda i: sec_labels[i])
            params = {}
            for p in spec.get("params", []):
                if p["type"] == "int":
                    params[p["name"]] = st.number_input(p["name"], value=int(p.get("default") or 0), step=5)
                elif p["type"] == "choice":
                    params[p["name"]] = st.selectbox(p["name"], p["options"])
                else:
                    params[p["name"]] = st.text_input(p["name"], value=p.get("default") or "",
                                                      placeholder="e.g. the inheritance documents")
            st.caption(f"Source: {spec['source_mode']} · reasoning effort: {spec.get('effort')}")
            if st.button("Apply edit", type="primary"):
                try:
                    res = apply_edit(store, LlmClient(store=store), run_id, action, sec_idx, params, base_version_id=vid)
                    st.session_state["last_edit"] = res
                    st.rerun()
                except Exception as e:
                    st.error(f"Edit failed: {e}")
            res = st.session_state.get("last_edit")
            if res:
                st.success(f"Saved as a new version{' - OFFLINE MOCK (no recorded fixture)' if res.offline_mock else ''}.")
                if res.navigation:
                    st.caption(f"Source located via {res.navigation.method}: {res.navigation.segment_ids}")
                for issue in res.issues:
                    st.warning(issue)
                b1, b2 = st.columns(2)
                for col, label, content in ((b1, "Before", res.before), (b2, "After", res.after)):
                    with col:
                        st.markdown(f"**{label}**")
                        bullets = content["bullets"] if "bullets" in content else \
                            [b for s in content["sections"] for b in s["bullets"]]
                        for b in bullets:
                            st.markdown(f"<small>• {fmt(b['text'])}</small>", unsafe_allow_html=True)

# --- 4 client tasks ----------------------------------------------------------------------
with tabs[3]:
    for r in publish.get("reconciliation") or []:
        st.warning(f"Cross-check: {plain(r)}")
    if not cands["candidates"]:
        st.info("No client-induced tasks detected.")
    for c in cands["candidates"]:
        task = CAT.task(c["task_code"]) or {"name": c["task_code"], "params": []}
        active = c["status"] in ("requested", "confirmed")
        with st.container(border=True):
            st.markdown(f"**{c['instance_id']} · {task['name']}** · status `{c['status']}` · confidence "
                        f"{c['confidence']:.2f} · initiated by {c['initiated_by']}"
                        + (" · **high risk - CA confirmation required**" if task.get("risk_tier") == "high" else ""))
            st.caption(plain(c["rationale"]))
            for e in c["evidence"]:
                st.markdown(f"<small>{e['turn']}: “{fmt(e['quote'])}”</small>", unsafe_allow_html=True)
            if not active:
                st.caption("Not extracted (mentioned only / cancelled) - kept for audit.")
                continue
            ext = result("extract_cit", c["instance_id"])
            ver = result("verify_cit", c["instance_id"])
            if not ext or ext["status"] != "ok":
                st.error(f"Extraction failed: {(ext or {}).get('validation')}")
                continue
            val = ext["validation"] or {}
            verdicts = {v["param_code"]: v for v in ((ver or {}).get("payload") or {}).get("verdicts", [])}
            badge = {"ok": "✅ complete", "incomplete": "🟡 incomplete", "invalid": "🔴 invalid"}[val.get("status", "ok")]
            st.markdown(f"Extraction: {badge}")
            rows = []
            for p in ext["payload"]["params"]:
                spec = next((x for x in task["params"] if x["code"] == p["param_code"]), {})
                v = verdicts.get(p["param_code"])
                rows.append({
                    "parameter": spec.get("name", p["param_code"]),
                    "value": plain(value_text(p.get("value"))),
                    "status": p["status"],
                    "evidence": " | ".join(f"{e['turn']}: {plain(e['quote'])}" for e in p["evidence"]),
                    "checks": "; ".join(val.get("params", {}).get(p["param_code"], [])) or "ok",
                    "verifier": (f"{v['verdict']}: {plain(v['note'])}" if v else "—"),
                })
            st.dataframe(rows, use_container_width=True, hide_index=True)
            disagreements = [v for v in verdicts.values() if v["verdict"] != "agree"]
            for v in disagreements:
                st.warning(f"Verifier {v['verdict']} on {v['param_code']}: {plain(v['note'])}")
            b1, b2, _ = st.columns([1, 1, 4])
            if b1.button("Confirm", key=f"ok-{c['instance_id']}"):
                store.add_review(run_id, "cit", c["instance_id"], "*", "", "confirmed")
                st.toast(f"{c['instance_id']} confirmed")
            if b2.button("Reject", key=f"no-{c['instance_id']}"):
                store.add_review(run_id, "cit", c["instance_id"], "*", "", "rejected")
                st.toast(f"{c['instance_id']} rejected")
    reviews = store.reviews(run_id)
    if reviews:
        st.caption("Review log: " + "; ".join(f"{r['item_id']} {r['action']}" for r in reviews))

# --- 5 topics ------------------------------------------------------------------------------
with tabs[4]:
    routing = routing_info.get("routing", {})
    st.markdown("**Domain routing** - which per-domain adjudication calls ran, and why")
    st.dataframe([{"domain": d, "name": CAT.domain(d)["name"], "routed by": ", ".join(src),
                   "regulatory": "yes" if d in CAT.regulatory_domains else ""} for d, src in routing.items()],
                 use_container_width=True, hide_index=True)
    rows = []
    for r in topic_results:
        for f in r["payload"]["flags"]:
            t = CAT.topic(f["topic_code"]) or {}
            issues = (r["validation"] or {}).get(f["topic_code"], [])
            rows.append({"domain": r["item_id"], "topic": t.get("name", f["topic_code"]), "level": f["level"],
                         "regulatory": "yes" if t.get("regulatory") else "", "confidence": round(f["confidence"], 2),
                         "segments": ", ".join(f["segment_ids"]),
                         "evidence": " | ".join(f"{e['turn']}: {plain(e['quote'])}" for e in f["evidence"]),
                         "checks": "; ".join(issues) or "ok"})
    st.markdown(f"**Topic flags** ({len(rows)})")
    st.dataframe(rows, use_container_width=True, hide_index=True)
    lex = routing_info.get("lexicon", {})
    with st.expander("Lexicon hits (deterministic safety net)"):
        st.dataframe([{"topic": k, "turns": ", ".join(v)} for k, v in lex.items()], hide_index=True)

# --- 6 cost & cache ------------------------------------------------------------------------
with tabs[5]:
    if any(c["estimated"] for c in calls):
        st.info("Replay mode: token figures are **estimates**. Run with LLM_MODE=live for measured `cached_tokens`.")
    if not ok_calls:
        st.info("All stages were reused from the application-side result cache - no LLM calls in this run.")
    else:
        df = pd.DataFrame(ok_calls)
        df["uncached"] = df["input_tokens"] - df["cached_tokens"]
        by_stage = df.groupby("stage")[["cached_tokens", "uncached", "output_tokens"]].sum()
        st.markdown("**Input tokens per stage: cached vs uncached**")
        st.bar_chart(by_stage[["cached_tokens", "uncached"]])
        prefixes = df[df["prefix_sha"] != "-"]["prefix_sha"].nunique()
        c1, c2, c3 = st.columns(3)
        c1.metric("Distinct transcript prefixes", prefixes, help="1 = every stage sent a byte-identical prefix")
        c2.metric("Output + reasoning tokens", int(df["output_tokens"].sum()))
        c3.metric("Monthly estimate at 500 calls/day", f"${df['cost_usd'].sum() * 500 * 22:,.0f}")
        st.dataframe(df[["stage", "item_id", "effort", "input_tokens", "cached_tokens", "output_tokens",
                         "reasoning_tokens", "latency_ms", "cost_usd", "prefix_sha"]],
                     use_container_width=True, hide_index=True)

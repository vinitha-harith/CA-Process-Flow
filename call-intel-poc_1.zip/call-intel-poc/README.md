# Call Intelligence PoC

A local, laptop-only proof of concept of the LLM call design for client-advisor call transcripts:
pseudonymization, conversation map, guideline-driven summary, client-induced task (CIT) detection and
parameter extraction, topic flagging, predefined summary edits, and cost/cache measurement.
It calls your Azure OpenAI **GPT-5.1** endpoint; nothing is deployed to Azure.

> **Synthetic data only.** Never put real client calls on a laptop. Use the bundled samples or
> `python -m poc generate` to create more.

## What the model sees: `PSEUDONYMIZE_TYPES`

| Setting | The model receives | Use when |
|---------|--------------------|----------|
| `DOB,AHV,CARD` (in `.env.example`) | Real names, emails, IBANs, phones, addresses - so tasks carry real values; date of birth, AHV and card numbers masked because no task needs them | Compliance approved client data on this deployment; data minimisation still applies |
| `none` | The transcript as spoken | Same approval, no minimisation needed |
| `all` (code default) | Placeholders only (`[IBAN_1]`); real values are re-hydrated locally | No approval for client data at the model |

Detection runs in every mode: the Privacy tab lists each identifier found and whether it went to the model as a
placeholder or as the real value. With real values, extraction gets deterministic checks instead of placeholder
checks - IBAN mod-97 checksum, email syntax, phone length, and a second reading of the cited turn: if the client
read the IBAN digit by digit, the code parses the digits itself and flags any difference from the model's value
("possibly misheard digits"). The summary guideline keeps IBANs, emails, phone numbers and dates of birth out of the
summary text in all modes; the task form holds them.

A private endpoint controls the network path, not where inference runs: a Data Zone Standard deployment can process
in any EU data-zone region. Make sure the approval covers the processing location as well as the endpoint.

## Quick start (offline, 2 minutes)

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate    macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
copy .env.example .env               # macOS/Linux: cp .env.example .env
pytest                               # 40 tests, all offline
python -m poc run call_001_en        # full pipeline in replay mode (bundled fixtures)
streamlit run app.py                 # review UI at http://localhost:8501
```

`LLM_MODE=replay` (the default in `.env.example`) replays hand-made responses for `call_001_en` - one set per
masking mode (`all`, `none`, `DOB,AHV,CARD`) - so you can rehearse the demo before touching the endpoint. Token figures in replay mode are **estimates** and labelled so.

## Connect your GPT-5.1 endpoint

1. Edit `.env`: set `LLM_MODE=live`, `AZURE_OPENAI_ENDPOINT`, `AZURE_OPENAI_API_KEY`, `AZURE_OPENAI_DEPLOYMENT`.
   `.env.example` shows the variants: v1 endpoint, classic `api-version`, a bank gateway with custom headers,
   or Entra ID (`az login`, `AZURE_OPENAI_AUTH=entra`).
2. Corporate TLS inspection: set `SSL_CERT_FILE` to the bank's CA bundle if you see certificate errors.
3. Run the probe:

   ```bash
   python -m poc check
   ```

   It makes three small calls and reports: plain call OK, strict forced tool call OK, `cached_tokens` on a
   repeated prefix, and whether the endpoint accepts `reasoning_effort`, `prompt_cache_key`,
   `parallel_tool_calls` and the `developer` role. Anything rejected is auto-disabled for the session, so the
   pipeline still runs.

4. Run live, and record the responses so you can demo offline later:

   ```bash
   # .env: LLM_MODE=live  LLM_RECORD=1
   python -m poc run call_001_en --force
   python -m poc run call_002_de --force     # German call, no bundled fixtures - live only until recorded
   python -m poc report
   ```

## Demo script (about 15 minutes, `streamlit run app.py`)

| # | Tab | What to show | Design point it proves |
|---|-----|--------------|------------------------|
| 1 | Privacy | Raw vs what the LLM saw, and the detection log (each identifier: placeholder or real value). With `PSEUDONYMIZE_TYPES=all`, paste a raw IBAN into the egress guard - blocked. | Configurable pseudonymization + egress guard |
| 2 | Outline | 10 segments, phases, domains, signals. Type "e-banking for his wife" in *Find in this call* - resolved by full-text search, no LLM call. | Conversation map = in-house tree index; navigator |
| 3 | Summary | Sections with turn citations; the cross-check warning ("Check whether the custody fees can be reduced" has no matching task type). Apply *Make shorter* or *Add a missing point*. | Guidelines, grounding, reconciliation, edit actions, versioning |
| 4 | Client tasks | 4 tasks; e-banking access level is `transact` because the client corrected "view only"; the spoken IBAN becomes `CH9300762011623852957` and passes the checksum and the second reading; verifier verdicts; Confirm/Reject. | Detect-then-extract, latest correction wins, deterministic value checks, high-risk verification |
| 5 | Topics | Routing table (map + lexicon), 19 flags with evidence, regulatory column. | Hierarchical routing + per-domain adjudication |
| 6 | Cost & cache | Cached vs uncached input per stage; "Distinct transcript prefixes = 1"; monthly estimate. | Warm-up then fan-out; uniform tool envelope |

Toggle **Show real values** in the sidebar to re-hydrate placeholders locally (they never go back to the LLM).

## The caching spike (do this in week 1)

```bash
python -m poc cache-experiment call_001_en
```

Runs three variants on your endpoint and prints `cached_tokens / input_tokens` per call:

- **A** uniform tool list + warm-up (the design): summary and detection should show a high cached share;
- **B** per-stage tool lists + warm-up: shows how much a per-stage schema breaks the shared prefix;
- **C** uniform tools, cold parallel fan-out: shows why simultaneous first calls miss.

The bundled sample is short (65 turns, ~3k tokens). For realistic numbers generate a 45-minute-length call:
`python -m poc generate call_003_de --lang de --turns 400`.

## Other commands

```bash
python -m poc list                                   # transcripts and runs
python -m poc navigate <run_id> "the inheritance"    # which segment a hint resolves to
python -m poc edit <run_id> TRANSLATE --param language=de
python -m poc edit <run_id> SHORTEN --section 4 --param target_words=30
python -m poc generate call_004_fr --lang fr --scenario "address change, complaint about a late payment"
```

## How it works

```
0 preprocess (no LLM)   parse -> pseudonymize -> render canonical transcript once -> sha256
1 conversation map      ONE call (warm-up): segments, phases, domains, signals -> repair_map -> SQLite + FTS5
2 fan-out (parallel)    summary | CIT detection | topic adjudication x routed domains
3 fan-out               CIT extraction x detected instances
4 fan-out               verification x high-risk instances
5 publish (no LLM)      evidence + type checks, reconciliation summary vs tasks, summary version 1
```

Every transcript call sends the same prefix - 6 strict tools (same order) + `global_rules.j2` + the
transcript - then a stage block. Stage results are stored under a content hash, so re-runs and retries cost
nothing (`python -m poc run call_001_en` twice: the second run makes 0 LLM calls).

| Path | What |
|------|------|
| `poc/pseudo.py` | Known-entity matching, spoken-form recognizers (DE/FR/IT/EN), configurable masking, detection log, egress guard |
| `poc/contracts.py` | Pydantic output contracts (regex for turn IDs and dates) |
| `poc/schema.py` | Pydantic -> Azure strict tool schema (strips `pattern`/`format`, injects catalog enums) |
| `poc/render.py`, `poc/prompts/` | Deterministic Jinja prompts, prefix hashing |
| `poc/llm.py` | Azure OpenAI wrapper: forced tool call, retries, capability fallback, usage logging, replay/record |
| `poc/mapping.py` | Map repair, deterministic fallback, lexicon booster, domain routing |
| `poc/navigator.py` | Full-text search over the outline, LLM routing call only if needed |
| `poc/validate.py` | Evidence, number grounding, CIT type and value checks (placeholder or real value), reconciliation |
| `poc/pipeline.py` | asyncio orchestrator with the Durable Functions stage shape |
| `poc/edits.py` | Predefined summary edits with guardrails and versioning |
| `catalogs/*.yaml` | Task catalog (4 types), topic catalog (26 topics / 8 domains), guidelines, edit actions |
| `app.py` | Streamlit review UI |

## From PoC to production

| PoC | Production | Change needed |
|-----|------------|---------------|
| `asyncio.gather` in `pipeline.py` | Durable Functions `task_all` | Each `_stage_*` becomes an activity; same inputs (IDs) |
| SQLite + FTS5 | PostgreSQL Flexible Server + `tsvector`/`unaccent` | Same tables; FTS query in SQL |
| YAML catalogs | Postgres catalog tables with versions and approval | Loader only |
| Hand-written prompts | GEPA-optimized, approved prompt versions | Templates become `prompt_version` rows |
| Streamlit | React review UI | UI only; the API surface is `pipeline`, `edits`, `navigator` |
| Regex + known entities | + Presidio/NER, tuned on annotated calls | Add a recognizer layer; leakage gate in CI |
| Replay fixtures | Golden set + eval gate | Fixtures are the seed of the golden set |

## Limitations (on purpose)

- No DSPy/GEPA here: it needs a labelled golden set first. The prompts are hand-written v1.
- Topic catalog is a 26-topic subset; routing is capped at 8 domains per call.
- Pseudonymization is pattern + known-entity based; if you rely on masking, measure leakage on annotated data first.
- Offline edit actions without a recorded fixture use a clearly labelled mock.
